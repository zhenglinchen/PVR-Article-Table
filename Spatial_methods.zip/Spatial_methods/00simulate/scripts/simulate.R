setwd("/XXXX/XXXX/spatial/00simulate/")
library("sp")
library("gstat")
library("spdep")
nsim <- 1000
data("volcano")
rain <- volcano
djungle <- matrix(data = runif(nrow(volcano)*ncol(volcano),0,1), nrow = nrow(volcano), ncol = ncol(volcano))

# Flatten the matrix into a vector
volcano_vector <- as.vector(volcano)

# Randomly sample 100 indices
sampled_indices <- sample(length(volcano_vector), 100)

# Retrieve the sampled elements
sampled_elements <- volcano_vector[sampled_indices]

# Convert indices to row and column indices in the matrix
row_indices <- (sampled_indices - 1) %% nrow(volcano) + 1
col_indices <- (sampled_indices - 1) %/% nrow(volcano) + 1

# Combine row and column indices
sampled_matrix_indices <- cbind(row_indices, col_indices)


# create dataframe including index, Longitude and latitude 
df <- data.frame(
  Number = 1:length(sampled_elements),
  Longitude = sampled_matrix_indices[, 2],
  Latitude = sampled_matrix_indices[, 1]
)

rain_values <- rain[cbind(df$Latitude, df$Longitude)]
djungle_values <- djungle[cbind(df$Latitude, df$Longitude)]

# add rain and djungle to df 
df$rain <- rain_values
df$djungle <- djungle_values

# check out df
head(df)

## simulate the spatial correlated error term 
coordinates <- df[,c("Longitude","Latitude")]
sp_points <- SpatialPoints(coordinates)
variogram_model <- vgm(psill = 1, model = "Sph", range = 0.1, nugget = 0)
set.seed(123)  # For reproducibility
simulated_field <- predict(gstat(formula = z~1, locations = ~x+y, dummy = TRUE, 
                                 beta = 0,model = variogram_model), newdata = sp_points, nsim = nsim)

e_name_list <- paste0("sim",c(1:nsim))

for (index in c(1:nsim)){
  e_name <- e_name_list[index]
  e_values <- simulated_field@data[,e_name]
  my_df <- df
  my_df$e <- e_values
  y <- 80-0.015*df$rain+10*e_values
  my_df$y <- y
  file_name <- paste0("results/",index,"_results.csv")
  write.csv(my_df,file = file_name,quote=F,row.names = F)
}


  
  
  