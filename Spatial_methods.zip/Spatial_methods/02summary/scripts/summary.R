setwd("/XXXX/XXXX/spatial/02summary/")
my_df <- read.csv("data/results.csv")


##SEVM####
SEVM_conflict_df <- my_df[c(((my_df$SEVM_xy_p-0.05) * (my_df$SEVM_yx_p-0.05)<0) |
                         ((my_df$SEVM_xy_p<0.05 & my_df$SEVM_yx_p<0.05)&
                         my_df$SEVM_xy_est*my_df$SEVM_yx_est<0)
                     ),]
##CAR
CAR_conflict_df <- my_df[c(((my_df$CAR_xy_p-0.05) * (my_df$CAR_yx_p-0.05)<0) |
                         ((my_df$CAR_xy_p<0.05 & my_df$CAR_yx_p<0.05)&
                            my_df$CAR_xy_est*my_df$CAR_yx_est<0)
),]

##SAR
SAR_conflict_df <- my_df[c(((my_df$SAR_xy_p-0.05) * (my_df$SAR_yx_p-0.05)<0) |
                             ((my_df$SAR_xy_p<0.05 & my_df$SAR_yx_p<0.05)&
                                my_df$SAR_xy_est*my_df$SAR_yx_est<0)
),]


##GLS
GLS_conflict_df <- my_df[c(((my_df$GLS_xy_p-0.05) * (my_df$GLS_yx_p-0.05)<0) |
                             ((my_df$GLS_xy_p<0.05 & my_df$GLS_yx_p<0.05)&
                                my_df$GLS_xy_est*my_df$GLS_yx_est<0)
),]


##GAM
GAM_conflict_df <- my_df[c(((my_df$GAM_xy_p-0.05) * (my_df$GAM_yx_p-0.05)<0) |
                             ((my_df$GAM_xy_p<0.05 & my_df$GAM_yx_p<0.05)&
                                my_df$GAM_xy_est*my_df$GAM_yx_est<0)
),]


##GLM
GLM_conflict_df <- my_df[c(((my_df$GLM_xy_p-0.05) * (my_df$GLM_yx_p-0.05)<0) |
                             ((my_df$GLM_xy_p<0.05 & my_df$GLM_yx_p<0.05)&
                                my_df$GLM_xy_est*my_df$GLM_yx_est<0)
),]


##GEE
GEE_conflict_df <- my_df[c(((my_df$GEE_xy_p-0.05) * (my_df$GEE_yx_p-0.05)<0) |
                             ((my_df$GEE_xy_p<0.05 & my_df$GEE_yx_p<0.05)&
                                my_df$GEE_xy_est*my_df$GEE_yx_est<0)
),]



dim(SEVM_conflict_df)
dim(CAR_conflict_df)
dim(SAR_conflict_df)
dim(GLS_conflict_df)
dim(GAM_conflict_df)
dim(GLM_conflict_df)
dim(GEE_conflict_df)



