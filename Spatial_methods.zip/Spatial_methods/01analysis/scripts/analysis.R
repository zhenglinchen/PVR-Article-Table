setwd("/XXXX/XXXX/spatial/01analysis")
library(spatialreg)
library(spdep)
library(mgcv)
library(geepack)
library(sp)

SEVM_xy_est_vec <- NULL
SEVM_xy_p_vec <- NULL
SEVM_yx_est_vec <- NULL
SEVM_yx_p_vec <- NULL
CAR_xy_est_vec <- NULL
CAR_xy_p_vec <- NULL
CAR_yx_est_vec <- NULL
CAR_yx_p_vec <- NULL
SAR_xy_est_vec <- NULL
SAR_xy_p_vec <- NULL
SAR_yx_est_vec <- NULL
SAR_yx_p_vec <- NULL
GLS_xy_est_vec <- NULL
GLS_xy_p_vec <- NULL
GLS_yx_est_vec <- NULL
GLS_yx_p_vec <- NULL
GAM_xy_est_vec <- NULL
GAM_xy_p_vec <- NULL
GAM_yx_est_vec <- NULL
GAM_yx_p_vec <- NULL
GLM_xy_est_vec <- NULL
GLM_xy_p_vec <- NULL
GLM_yx_est_vec <- NULL
GLM_yx_p_vec <- NULL
GEE_xy_est_vec <- NULL
GEE_xy_p_vec <- NULL
GEE_yx_est_vec <- NULL
GEE_yx_p_vec <- NULL



for (index in c(1:1000)){
  file_name <- paste0("data/",index,"_results.csv")
  my_df <- read.csv(file_name)
  y <- "y"
  x <- "rain"
  
  ### SEVM #####
  SEVM<-function(df,x,y){
    coordinates <- df[,c("Longitude","Latitude")]
    sp_points <- SpatialPoints(coordinates)
    
    neighbors <- knn2nb(knearneigh(sp_points, k = 4))  # 例如，使用最近的4个邻居
    weights_matrix <- nb2listw(neighbors, style = "W")  # "W" 表示行标准化的权重  
    
    me_formula <- as.formula(paste0(y,"~",x))
    
    # Initialize 'sevm_formula' outside the tryCatch block
    sevm_formula <- as.formula(paste0(y, "~", x))
    
    # Use tryCatch to handle potential errors
    tryCatch({
      # Attempt to compute Moran's Eigenvectors
      me_result <- ME(formula = me_formula, data = df, listw = weights_matrix, na.action = na.exclude)
      
      # If successful, update 'sevm_formula' to include eigenvectors
      sevm_formula <- as.formula(paste0(y, "~", x, "+me_result$vectors"))
    }, error = function(e) {
      # If an error occurs, 'sevm_formula' remains as initially defined
      message("Error in computing ME: ", e$message)
    })
    
    sevm_model <- lm(sevm_formula , data = df)
    est <- summary(sevm_model)$coefficients[2,1]
    p <- summary(sevm_model)$coefficients[2,4]
    return(c(est,p))
  }
  
  SEVM_xy_fit <- SEVM(my_df,x,y)
  SEVM_yx_fit <- SEVM(my_df,y,x)
  
  SEVM_xy_est <- SEVM_xy_fit[1]
  SEVM_xy_p <- SEVM_xy_fit[2]
  
  SEVM_yx_est <- SEVM_yx_fit[1]
  SEVM_yx_p <- SEVM_yx_fit[2]
  
  ### CAR #####
  CAR <- function(df,x,y){
    coordinates <- df[,c("Longitude","Latitude")]
    sp_points <- SpatialPoints(coordinates)
    
    neighbors <- knn2nb(knearneigh(sp_points, k = 4))  
    weights_matrix <- nb2listw(neighbors, style = "W")
    
    CAR_formula <- as.formula(paste0(y,"~",x))
    CAR_fit <- spautolm(CAR_formula,df,listw = weights_matrix,family = "CAR")
    est <- summary(CAR_fit)$Coef[2,1]
    p <- summary(CAR_fit)$Coef[2,4]
    return(c(est,p))
  }
  
  CAR_xy_fit <- CAR(my_df,x,y)
  CAR_yx_fit <- CAR(my_df,y,x)
  
  CAR_xy_est <- CAR_xy_fit[1]
  CAR_xy_p <- CAR_xy_fit[2]
  
  CAR_yx_est <- CAR_yx_fit[1]
  CAR_yx_p <- CAR_yx_fit[2]
  
  
  ### SAR #####
  SAR <- function(df,x,y){
    coordinates <- df[,c("Longitude","Latitude")]
    sp_points <- SpatialPoints(coordinates)
    
    neighbors <- knn2nb(knearneigh(sp_points, k = 4))  
    weights_matrix <- nb2listw(neighbors, style = "W")
    
    SAR_formula <- as.formula(paste0(y,"~",x))
    SAR_fit <- spautolm(SAR_formula,df,listw = weights_matrix,family = "SAR")
    est <- summary(SAR_fit)$Coef[2,1]
    p <- summary(SAR_fit)$Coef[2,4]
    return(c(est,p))
  }
  
  SAR_xy_fit <- SAR(my_df,x,y)
  SAR_yx_fit <- SAR(my_df,y,x)
  
  SAR_xy_est <- SAR_xy_fit[1]
  SAR_xy_p <- SAR_xy_fit[2]
  
  SAR_yx_est <- SAR_yx_fit[1]
  SAR_yx_p <- SAR_yx_fit[2]
  
  ### GLS exp ####
  GLS <- function(df,x,y){
    
    GLS_formula <- as.formula(paste0(y,"~",x))
    
    GLS_fit <- gls(GLS_formula, data = df,correlation = corExp(form = ~ Longitude + Latitude))
    est <- summary(GLS_fit)$tTable[2,1]
    p <- summary(GLS_fit)$tTable[2,4]
    return(c(est,p))
  }
  
  GLS_xy_fit <- GLS(my_df,x,y)
  GLS_yx_fit <- GLS(my_df,y,x)
  
  GLS_xy_est <- GLS_xy_fit[1]
  GLS_xy_p <- GLS_xy_fit[2]
  
  GLS_yx_est <- GLS_yx_fit[1]
  GLS_yx_p <- GLS_yx_fit[2]
  
  ### trend-surface GAM ####
  GAM <- function(df,x,y){
    GAM_formula <- as.formula(paste0(y,"~s(Longitude,Latitude)+",x))
    GAM_fit <- gam(GAM_formula, data = df, family = "gaussian")
    est <- summary(GAM_fit)$p.coeff[2]
    p <- summary(GAM_fit)$p.pv[2]
    return(c(est,p))
  }
  
  GAM_xy_fit <- GAM(my_df,x,y)
  GAM_yx_fit <- GAM(my_df,y,x)
  
  GAM_xy_est <- GAM_xy_fit[1]
  GAM_xy_p <- GAM_xy_fit[2]
  
  GAM_yx_est <- GAM_yx_fit[1]
  GAM_yx_p <- GAM_yx_fit[2]
  
  ### GLM ####
  
  GLM <- function(df,x,y){
    GLM_formula <- as.formula(paste0(y,"~",x))
    GLM_fit <- glm(GLM_formula, data = df, family = "Gamma")
    est <- summary(GLM_fit)$coefficients[2,1]
    p <- summary(GLM_fit)$coefficients[2,4]
    residual <- GLM_fit$residuals
    
    coordinates <- df[,c("Longitude","Latitude")]
    sp_points <- SpatialPoints(coordinates)
    
    neighbors <- knn2nb(knearneigh(sp_points, k = 4))  
    weights_matrix <- nb2listw(neighbors, style = "W")
    moran_result <- moran.test(residual, weights_matrix)
    moranI <- moran_result$estimate[1]
    return(c(est,p,moranI))
  }
  
  GLM_xy_fit <- GLM(my_df,x,y)
  GLM_yx_fit <- GLM(my_df,y,x)
  
  GLM_xy_est <- GLM_xy_fit[1]
  GLM_xy_p <- GLM_xy_fit[2]
  GLM_xy_moranI <- GLM_xy_fit[3]
  
  
  GLM_yx_est <- GLM_yx_fit[1]
  GLM_yx_p <- GLM_yx_fit[2]
  GLM_yx_moranI <- GLM_yx_fit[3]
  
  
  
  ### GEE ####
  GEE <- function(df,x,y,a1){
    coords <- df[,c("Longitude","Latitude")]
    dist_matrix <- as.matrix(dist(coords))
    cor_matrix <- a1^dist_matrix
    GEE_formula <- as.formula(paste0(y,"~",x))
    gee_fit <- geeglm(GEE_formula, data = df, id=Number,zcor = cor_matrix)
    est <- summary(gee_fit)$coefficients[2,1]
    p <- summary(gee_fit)$coefficients[2,4]
    return(c(est,p))
  }
  
  GEE_xy_fit <- GEE(my_df,x,y,GLM_xy_moranI)
  GEE_yx_fit <- GEE(my_df,y,x,GLM_yx_moranI)
  
  GEE_xy_est <- GEE_xy_fit[1]
  GEE_xy_p <- GEE_xy_fit[2]
  
  GEE_yx_est <- GEE_yx_fit[1]
  GEE_yx_p <- GEE_yx_fit[2]
  
  
  SEVM_xy_est_vec <- c(SEVM_xy_est_vec,SEVM_xy_est)
  SEVM_xy_p_vec <- c(SEVM_xy_p_vec,SEVM_xy_p)
  SEVM_yx_est_vec <- c(SEVM_yx_est_vec,SEVM_yx_est)
  SEVM_yx_p_vec <- c(SEVM_yx_p_vec,SEVM_yx_p)
  CAR_xy_est_vec <- c(CAR_xy_est_vec,CAR_xy_est)
  CAR_xy_p_vec <- c(CAR_xy_p_vec,CAR_xy_p)
  CAR_yx_est_vec <- c(CAR_yx_est_vec,CAR_yx_est)
  CAR_yx_p_vec <- c(CAR_yx_p_vec,CAR_yx_p)
  SAR_xy_est_vec <- c(SAR_xy_est_vec,SAR_xy_est)
  SAR_xy_p_vec <- c(SAR_xy_p_vec,SAR_xy_p)
  SAR_yx_est_vec <- c(SAR_yx_est_vec,SAR_yx_est)
  SAR_yx_p_vec <- c(SAR_yx_p_vec,SAR_yx_p)
  GLS_xy_est_vec <- c(GLS_xy_est_vec,GLS_xy_est)
  GLS_xy_p_vec <- c(GLS_xy_p_vec,GLS_xy_p)
  GLS_yx_est_vec <- c(GLS_yx_est_vec,GLS_yx_est)
  GLS_yx_p_vec <- c(GLS_yx_p_vec,GLS_yx_p)
  GAM_xy_est_vec <- c(GAM_xy_est_vec,GAM_xy_est)
  GAM_xy_p_vec <- c(GAM_xy_p_vec,GAM_xy_p)
  GAM_yx_est_vec <- c(GAM_yx_est_vec,GAM_yx_est)
  GAM_yx_p_vec <- c(GAM_yx_p_vec,GAM_yx_p)
  GLM_xy_est_vec <- c(GLM_xy_est_vec,GLM_xy_est)
  GLM_xy_p_vec <- c(GLM_xy_p_vec,GLM_xy_p)
  GLM_yx_est_vec <- c(GLM_yx_est_vec,GLM_yx_est)
  GLM_yx_p_vec <- c(GLM_yx_p_vec,GLM_yx_p)
  GEE_xy_est_vec <- c(GEE_xy_est_vec,GEE_xy_est)
  GEE_xy_p_vec <- c(GEE_xy_p_vec,GEE_xy_p)
  GEE_yx_est_vec <- c(GEE_yx_est_vec,GEE_yx_est)
  GEE_yx_p_vec <- c(GEE_yx_p_vec,GEE_yx_p)
  
  
}

results <- data.frame(SEVM_xy_est_vec,
                      SEVM_xy_p_vec,
                      SEVM_yx_est_vec,
                      SEVM_yx_p_vec,
                      CAR_xy_est_vec,
                      CAR_xy_p_vec,
                      CAR_yx_est_vec,
                      CAR_yx_p_vec,
                      SAR_xy_est_vec,
                      SAR_xy_p_vec,
                      SAR_yx_est_vec,
                      SAR_yx_p_vec,
                      GLS_xy_est_vec,
                      GLS_xy_p_vec,
                      GLS_yx_est_vec,
                      GLS_yx_p_vec,
                      GAM_xy_est_vec,
                      GAM_xy_p_vec,
                      GAM_yx_est_vec,
                      GAM_yx_p_vec,
                      GLM_xy_est_vec,
                      GLM_xy_p_vec,
                      GLM_yx_est_vec,
                      GLM_yx_p_vec,
                      GEE_xy_est_vec,
                      GEE_xy_p_vec,
                      GEE_yx_est_vec,
                      GEE_yx_p_vec
)

colnames(results) <- c("SEVM_xy_est",
                       "SEVM_xy_p",
                       "SEVM_yx_est",
                       "SEVM_yx_p",
                       "CAR_xy_est",
                       "CAR_xy_p",
                       "CAR_yx_est",
                       "CAR_yx_p",
                       "SAR_xy_est",
                       "SAR_xy_p",
                       "SAR_yx_est",
                       "SAR_yx_p",
                       "GLS_xy_est",
                       "GLS_xy_p",
                       "GLS_yx_est",
                       "GLS_yx_p",
                       "GAM_xy_est",
                       "GAM_xy_p",
                       "GAM_yx_est",
                       "GAM_yx_p",
                       "GLM_xy_est",
                       "GLM_xy_p",
                       "GLM_yx_est",
                       "GLM_yx_p",
                       "GEE_xy_est",
                       "GEE_xy_p",
                       "GEE_yx_est",
                       "GEE_yx_p"
)


write.csv(results,file = "results/results.csv")

