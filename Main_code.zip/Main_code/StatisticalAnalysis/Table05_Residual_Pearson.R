library(ggplot2)
library(tidyr)
setwd("/home/chenzl/03PVR_modify/fixed_128_tree/analysis/")

input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results1/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results1/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results1/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results1/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results1/final_csv/final.csv")


new_df1 <- read.csv(input_csv_1)
new_df2 <- read.csv(input_csv_2)
new_df3 <- read.csv(input_csv_3)
new_df4 <- read.csv(input_csv_4)
new_df5 <- read.csv(input_csv_5)


count_new_select <- function(my_df){
  new_method_ESRRV_correct <- my_df[(my_df$ESRRV_p < 0.05 & my_df$pearson_p < 0.05 & 
                                       my_df$ESRRV_est * my_df$pearson_est > 0) | 
                                      (my_df$ESRRV_p >= 0.05 & my_df$pearson_p >= 0.05), ]
  
  new_method_moran_correct <- my_df[(my_df$moran_p < 0.05 & my_df$pearson_p < 0.05 & 
                                       my_df$moran_est * my_df$pearson_est > 0) | 
                                      (my_df$moran_p >= 0.05 & my_df$pearson_p >= 0.05), ]
  
  new_method_stepwise_correct <- my_df[(my_df$stepwise_p < 0.05 & my_df$pearson_p < 0.05 & 
                                          my_df$stepwise_est * my_df$pearson_est > 0) | 
                                         (my_df$stepwise_p >= 0.05 & my_df$pearson_p >= 0.05), ]
  
  a <- table(new_method_ESRRV_correct$X)
  b <- table(new_method_moran_correct$X)
  c <- table(new_method_stepwise_correct$X)
  return(list(a,b,c))
}

ESRBS_AND1 <- count_new_select(new_df1)[[1]]
moran_AND1 <- count_new_select(new_df1)[[2]]
stepwise_AND1 <- count_new_select(new_df1)[[3]]

ESRBS_AND2 <- count_new_select(new_df2)[[1]]
moran_AND2 <- count_new_select(new_df2)[[2]]
stepwise_AND2 <- count_new_select(new_df2)[[3]]

ESRBS_AND3 <- count_new_select(new_df3)[[1]]
moran_AND3 <- count_new_select(new_df3)[[2]]
stepwise_AND3 <- count_new_select(new_df3)[[3]]

ESRBS_AND4 <- count_new_select(new_df4)[[1]]
moran_AND4 <- count_new_select(new_df4)[[2]]
stepwise_AND4 <- count_new_select(new_df4)[[3]]

res_mat <- cbind(ESRBS_AND1,moran_AND1,stepwise_AND1,
                 ESRBS_AND2,moran_AND2,stepwise_AND2,
                 ESRBS_AND3,moran_AND3,stepwise_AND3,
                 ESRBS_AND4,moran_AND4,stepwise_AND4
)

res_df <- data.frame(t(res_mat))

rownames(res_df) <- c("ESRRV1","moran1","stepwise1",
                      "ESRRV2","moran2","stepwise2",
                      "ESRRV3","moran3","stepwise3",
                      "ESRRV4","moran4","stepwise4"
)

write.csv(res_df,"./results/01Residual_Cor_Pearson.csv")
