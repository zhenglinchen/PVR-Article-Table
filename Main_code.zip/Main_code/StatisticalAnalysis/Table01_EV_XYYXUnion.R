library(ggplot2)
library(tidyr)
library(stringr)
### 1. PVR EV_number ####

input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results01/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results01/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results01/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results01/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results01/final_csv/final.csv")


raw_df1 <- read.csv(input_csv_1)
raw_df2 <- read.csv(input_csv_2)
raw_df3 <- read.csv(input_csv_3)
raw_df4 <- read.csv(input_csv_4)
raw_df5 <- read.csv(input_csv_5)

raw_df1$group <- rep("BM1&BM1+BM2",nrow(raw_df1))
raw_df2$group <- rep("BM&BM+Norm",nrow(raw_df2))
raw_df3$group <- rep("Norm&Norm+BM",nrow(raw_df3))
raw_df4$group <- rep("Norm1&Norm1+Norm2",nrow(raw_df4))
raw_df5$group <- rep("Shift",nrow(raw_df5))

get_union <- function(my_df){
  try_df <- my_df[,c("X","pvr_moran_yx_EV","pvr_moran_xy_EV","group")]
  try_df[,"pvr_moran_union_EV"] <- paste0(try_df[,"pvr_moran_xy_EV"],"+",try_df[,"pvr_moran_yx_EV"])
  ##try_EV <- "0+c1+c2"
  count_vec <- sapply(try_df[,"pvr_moran_union_EV"], function(try_EV) {
    # 1. 按 "+" 分割
    EV_vec <- unlist(strsplit(try_EV, "\\+"))
    
    # 2. 去除 "0"
    EV_vec <- EV_vec[EV_vec != "0"]
    
    # 3. 取唯一值并统计个数
    length(unique(EV_vec))
  })
  
  # 移除名称（可选）
  names(count_vec) <- NULL
  
  try_df$pvr_moran_union_npar <- count_vec
  
  return(try_df)
}

new_df1 <- get_union(raw_df1)
new_df2 <- get_union(raw_df2)
new_df3 <- get_union(raw_df3)
new_df4 <- get_union(raw_df4)
new_df5 <- get_union(raw_df5)



get_median_number <- function(new_df){
  res_vec <- NULL
  for (index in c(1:8)){
    median_npar <- median(new_df[new_df[,"X"] == index, "pvr_moran_union_npar"])
    res_vec <- c(res_vec,median_npar)
  }
  return(res_vec)
}

res1 <- get_median_number(new_df1)
res2 <- get_median_number(new_df2)
res3 <- get_median_number(new_df3)
res4 <- get_median_number(new_df4)
res5 <- get_median_number(new_df5)

res_df <- rbind(res1,res2,res3,res4,res5)

all_df <- rbind(new_df1,new_df2,new_df3,new_df4,new_df5)

table(new_df1$pvr_moran_union_npar)
table(new_df2$pvr_moran_union_npar)
table(new_df3$pvr_moran_union_npar)
table(new_df4$pvr_moran_union_npar)
table(new_df5$pvr_moran_union_npar)



