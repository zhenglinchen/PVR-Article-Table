library(ggplot2)
library(tidyr)


df1 <- read.csv("../BM1_BM1+BM2/01analysis/results5/final_csv/final.csv")
df2 <- read.csv("../BM_BM+Norm/01analysis/results5/final_csv/final.csv")
df3 <- read.csv("../Norm_Norm+BM/01analysis/results5/final_csv/final.csv")
df4 <- read.csv("../Norm1_Norm1+Norm2/01analysis/results5/final_csv/final.csv")
df5 <- read.csv("../shift/01analysis/results5/final_csv/final.csv")


AIC_min_noselect_model <- function(new_df){
  new_df$PGLS_noselect_best <- apply(new_df[, c("BM_aic", "OUrandom_aic", "lambda_aic")], 1, function(row) {
    best_col <- names(row)[which.min(row)]
    sub("_aic$", "", best_col)  # 去掉 "_aic" 保留前缀
  })
  
  # 为新列 PGLS_best_est 和 PGLS_best_p 赋值
  new_df$PGLS_noselect_best_est <- apply(new_df, 1, function(row) {
    prefix <- row["PGLS_noselect_best"]
    row[paste0(prefix, "_est")]
  })
  
  new_df$PGLS_noselect_best_p <- apply(new_df, 1, function(row) {
    prefix <- row["PGLS_noselect_best"]
    row[paste0(prefix, "_p")]
  })
  
  return(new_df)
}

no_criteria <- function(my_df,scenario){
  
  template_yx <- c("BM_yx_est", "BM_yx_p", "BM_yx_aic")
  template_new <- c("BM_est","BM_p","BM_aic")
  
  keywords <- c("OUrandom", "EB", "lambda")
  result_yx <- lapply(keywords, function(k) gsub("BM", k, template_yx))
  result_new <- lapply(keywords, function(k) gsub("BM", k, template_new))
  
  # 将列表结果展开为一个向量
  final_vector_yx <- c(template_yx, unlist(result_yx))
  final_vector_new <- c(template_new, unlist(result_new))
  
  new_X2X1_df <- my_df[,c("X",final_vector_yx,"X2_lambda","X1_lambda","final_p","final_est")]
  colnames(new_X2X1_df) <- c("X",final_vector_new,"y_lambda","x_lambda","final_p","final_est")
  
  results_df <- AIC_min_noselect_model(new_X2X1_df)
  
  results_df$index <- rownames(results_df)
  
  return(results_df[,c("index","PGLS_noselect_best","PGLS_noselect_best_est","PGLS_noselect_best_p")])
  
}

res12 <- no_criteria(df1,"BM1_BM1+BM2")
final_df1 <- cbind(res12,df1)

res22 <- no_criteria(df2,"BM_BM+Norm")
final_df2 <- cbind(res22,df2)

res32 <- no_criteria(df3,"Norm_Norm+BM")
final_df3 <- cbind(res32,df3)

res42 <- no_criteria(df4,"Norm1_Norm1+Norm2")
final_df4 <- cbind(res42,df4)

res52 <- no_criteria(df5,"shift")
final_df5 <- cbind(res52,df5)


process_best_acc_df <- function(my_df){
  
  method_yx_est <- paste0("PGLS_noselect_best_est")
  method_yx_p <- paste0("PGLS_noselect_best_p")
  
  my_df[,method_yx_est] <- as.numeric(my_df[,method_yx_est])
  my_df[,method_yx_p] <- as.numeric(my_df[,method_yx_p])
  
  my_df$X <- factor(my_df$X)
  
  method_yx_correct_pos <- my_df[(my_df[,method_yx_p] < 0.05 & my_df$spearman_p < 0.05 & 
                                    my_df[,method_yx_est] * my_df$spearman_est > 0), ]
  
  method_yx_correct_neg <- my_df[(my_df[,method_yx_p] >= 0.05 & my_df$spearman_p >= 0.05), ]
  
  c <- table(method_yx_correct_pos$X)
  d <- table(method_yx_correct_neg$X)
  
  e <- c+d
  et <- t(e)
  return(et)
}

PGLS_best_acc1 <- process_best_acc_df(final_df1)
PGLS_best_acc2 <- process_best_acc_df(final_df2)
PGLS_best_acc3 <- process_best_acc_df(final_df3)
PGLS_best_acc4 <- process_best_acc_df(final_df4)
PGLS_best_acc5 <- process_best_acc_df(final_df5)

best_mat_acc <- rbind(PGLS_best_acc1,PGLS_best_acc2,PGLS_best_acc3,PGLS_best_acc4,PGLS_best_acc5)
best_df_acc <- data.frame(best_mat_acc)
best_df_acc$scenario <- c(rep("BM1_BM1+BM2",1),rep("BM_BM+Norm",1),
                      rep("Norm_Norm+BM",1),rep("Norm1_Norm1+Norm2",1),
                      rep("shift",1))
best_df_acc$group <- rep("PGLS_best_accuracy",5)

write.csv(best_df_acc,"results/04PGLS_Best_Accuracy_Spearman.csv")


process_best_df <- function(my_df){
  
  method_yx_est <- paste0("PGLS_noselect_best_est")
  method_yx_p <- paste0("PGLS_noselect_best_p")
  
  my_df[,method_yx_est] <- as.numeric(my_df[,method_yx_est])
  my_df[,method_yx_p] <- as.numeric(my_df[,method_yx_p])
  
  my_df$X <- factor(my_df$X)
  
  method_yx_correct_pos <- my_df[(my_df[,method_yx_p] < 0.05 & my_df$spearman_p < 0.05 & 
                                    my_df[,method_yx_est] * my_df$spearman_est > 0), ]
  
  method_yx_correct_neg <- my_df[(my_df[,method_yx_p] >= 0.05 & my_df$spearman_p >= 0.05), ]
  
  c <- table(method_yx_correct_pos$X)
  d <- table(method_yx_correct_neg$X)
  
  e <- cbind(c,d)
  et <- t(e)
  return(et)
}

PGLS_best1 <- process_best_df(final_df1)
PGLS_best2 <- process_best_df(final_df2)
PGLS_best3 <- process_best_df(final_df3)
PGLS_best4 <- process_best_df(final_df4)
PGLS_best5 <- process_best_df(final_df5)


best_mat <- rbind(PGLS_best1,PGLS_best2,PGLS_best3,PGLS_best4,PGLS_best5)
best_df <- data.frame(best_mat)
best_df$scenario <- c(rep("BM1_BM1+BM2",2),rep("BM_BM+Norm",2),
                      rep("Norm_Norm+BM",2),rep("Norm1_Norm1+Norm2",2),
                      rep("shift",2))
best_df$group <- rep(c("PGLS_best_pos","PGLS_best_neg"),5)

write.csv(best_df,"results/04PGLS_Best_PosAndNeg_Spearman.csv")







BM_df1 <- final_df1[final_df1[,"PGLS_noselect_best"]=="BM",]
NoBM_df1 <- final_df1[final_df1[,"PGLS_noselect_best"]!="BM",]

BM_df2 <- final_df2[final_df2[,"PGLS_noselect_best"]=="BM",]
NoBM_df2 <- final_df2[final_df2[,"PGLS_noselect_best"]!="BM",]

BM_df3 <- final_df3[final_df3[,"PGLS_noselect_best"]=="BM",]
NoBM_df3 <- final_df3[final_df3[,"PGLS_noselect_best"]!="BM",]

BM_df4 <- final_df4[final_df4[,"PGLS_noselect_best"]=="BM",]
NoBM_df4 <- final_df4[final_df4[,"PGLS_noselect_best"]!="BM",]

BM_df5 <- final_df5[final_df5[,"PGLS_noselect_best"]=="BM",]
NoBM_df5 <- final_df5[final_df5[,"PGLS_noselect_best"]!="BM",]


write.csv(x = BM_df1,file = "./data_BM/results5/BM1_BM1+BM2.csv", quote = FALSE,row.names = FALSE)
write.csv(x = NoBM_df1, file = "./data_NoBM/results5/BM1_BM1+BM2.csv", quote = FALSE,row.names = FALSE)

write.csv(x = BM_df2,file = "./data_BM/results5/BM_BM+Norm.csv", quote = FALSE,row.names = FALSE)
write.csv(x = NoBM_df2, file = "./data_NoBM/results5/BM_BM+Norm.csv", quote = FALSE,row.names = FALSE)

write.csv(x = BM_df3,file = "./data_BM/results5/Norm_Norm+BM.csv", quote = FALSE,row.names = FALSE)
write.csv(x = NoBM_df3, file = "./data_NoBM/results5/Norm_Norm+BM.csv", quote = FALSE,row.names = FALSE)

write.csv(x = BM_df4,file = "./data_BM/results5/Norm1_Norm1+Norm2.csv", quote = FALSE,row.names = FALSE)
write.csv(x = NoBM_df4, file = "./data_NoBM/results5/Norm1_Norm1+Norm2.csv", quote = FALSE,row.names = FALSE)

write.csv(x = BM_df5,file = "./data_BM/results5/shift.csv", quote = FALSE,row.names = FALSE)
write.csv(x = NoBM_df5, file = "./data_NoBM/results5/shift.csv", quote = FALSE,row.names = FALSE)








