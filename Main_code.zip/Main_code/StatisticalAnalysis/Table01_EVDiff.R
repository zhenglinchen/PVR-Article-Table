library(ggplot2)
library(tidyr)

input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results01/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results01/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results01/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results01/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results01/final_csv/final.csv")

df1 <- read.csv(input_csv_1)
df2 <- read.csv(input_csv_2)
df3 <- read.csv(input_csv_3)
df4 <- read.csv(input_csv_4)
df5 <- read.csv(input_csv_5)

count_diff_EV <- function(my_df,m_name){
  my_df$X <- factor(my_df$X)
  xy_L1_col <- paste0("pvr_",m_name,"_xy_EV")
  yx_L1_col <- paste0("pvr_",m_name,"_yx_EV")
  
  
  L1_diff <- table(my_df[my_df[,xy_L1_col] != my_df[,yx_L1_col],"X"])
  return(L1_diff)
  
}

BM1_ESRBS <- count_diff_EV(df1,"ESRBS")
BM1_moran <- count_diff_EV(df1,"moran")
BM1_stepwise <- count_diff_EV(df1,"stepwise")

BM_ESRBS <- count_diff_EV(df2,"ESRBS")
BM_moran <- count_diff_EV(df2,"moran")
BM_stepwise <- count_diff_EV(df2,"stepwise")

Norm_ESRBS <- count_diff_EV(df3,"ESRBS")
Norm_moran <- count_diff_EV(df3,"moran")
Norm_stepwise <- count_diff_EV(df3,"stepwise")

Norm1_ESRBS <- count_diff_EV(df4,"ESRBS")
Norm1_moran <- count_diff_EV(df4,"moran")
Norm1_stepwise <- count_diff_EV(df4,"stepwise")

shift_ESRBS <- count_diff_EV(df5,"ESRBS")
shift_moran <- count_diff_EV(df5,"moran")
shift_stepwise <- count_diff_EV(df5,"stepwise")



res_mat <- cbind(BM1_ESRBS,BM1_stepwise,BM1_moran,
                 BM_ESRBS,BM_stepwise,BM_moran,
                 Norm_ESRBS,Norm_stepwise,Norm_moran,
                 Norm1_ESRBS,Norm1_stepwise,Norm1_moran,
                 shift_ESRBS,shift_stepwise,shift_moran)

res_df <- as.data.frame(t(res_mat))

write.csv(res_df,"./results/01_00DifferentEV.csv")




