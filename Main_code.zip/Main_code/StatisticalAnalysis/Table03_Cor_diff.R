library(ggplot2)
library(tidyr)

input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results01/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results01/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results01/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results01/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results01/final_csv/final.csv")

raw_df1 <- read.csv(input_csv_1)
raw_df2 <- read.csv(input_csv_2)
raw_df3 <- read.csv(input_csv_3)
raw_df4 <- read.csv(input_csv_4)
raw_df5 <- read.csv(input_csv_5)


input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results2/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results2/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results2/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results2/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results2/final_csv/final.csv")


df1 <- read.csv(input_csv_1)
df2 <- read.csv(input_csv_2)
df3 <- read.csv(input_csv_3)
df4 <- read.csv(input_csv_4)
df5 <- read.csv(input_csv_5)

split_final_df <- function(my_df){
  benchmark_df <- my_df[,c("spearman_p","spearman_est")]
  return(benchmark_df)
}

benchmark_df1 <- split_final_df(df1)
benchmark_df2 <- split_final_df(df2)
benchmark_df3 <- split_final_df(df3)
benchmark_df4 <- split_final_df(df4)
benchmark_df5 <- split_final_df(df5)

new_df1 <- cbind(raw_df1,benchmark_df1)
new_df2 <- cbind(raw_df2,benchmark_df2)
new_df3 <- cbind(raw_df3,benchmark_df3)
new_df4 <- cbind(raw_df4,benchmark_df4)
new_df5 <- cbind(raw_df5,benchmark_df5)


ESRBS_count_correct_conflict <- function(my_df,name){
  
  my_df$index <- c(1:8000)
  
  my_df$X <- as.factor(my_df$X)
  pvr_xy_p <- paste0("pvr_ESRBS_xy_p")
  pvr_yx_p <- paste0("pvr_ESRBS_yx_p")
  pvr_xy_est <- paste0("pvr_ESRBS_xy_est")
  pvr_yx_est <- paste0("pvr_ESRBS_yx_est")
  
  p_df <- my_df[c(my_df[,pvr_xy_p]<0.05 & my_df[,pvr_yx_p]>=0.05)|c(my_df[,pvr_xy_p]>=0.05 & my_df[,pvr_yx_p]<0.05)|
                  c((my_df[,pvr_xy_p]<0.05 & my_df[,pvr_yx_p]<0.05) & (my_df[,pvr_xy_est]*my_df[,pvr_yx_est]<0)),]
  
  
  index <- p_df$index
  
  new_df <- my_df[,c("X","index","pvr_ESRBS_xy_p","pvr_ESRBS_xy_est","pvr_ESRBS_xy_npar",
                     "pvr_ESRBS_yx_p","pvr_ESRBS_yx_est","pvr_ESRBS_yx_npar"
  )]
  
  colnames(new_df) <- c("X","index","pvr_ESRBS_xy_p","pvr_ESRBS_xy_est","pvr_ESRBS_xy_npar",
                        "pvr_ESRBS_yx_p","pvr_ESRBS_yx_est","pvr_ESRBS_yx_npar")
  
  new_df$pvr_ESRBS_xy_df <- 128-new_df$pvr_ESRBS_xy_npar-2
  new_df$pvr_ESRBS_yx_df <- 128-new_df$pvr_ESRBS_yx_npar-2
  
  
  new_df$pvr_ESRBS_xy_t_value <- qt(1 - new_df$pvr_ESRBS_xy_p / 2, new_df$pvr_ESRBS_xy_df)
  new_df$pvr_ESRBS_xy_r <- new_df$pvr_ESRBS_xy_t_value / sqrt(new_df$pvr_ESRBS_xy_t_value^2 + new_df$pvr_ESRBS_xy_df)
  new_df$pvr_ESRBS_xy_r[is.nan(new_df$pvr_ESRBS_xy_r)] <- 1
  
  new_df$pvr_ESRBS_yx_t_value <- qt(1 - new_df$pvr_ESRBS_yx_p / 2, new_df$pvr_ESRBS_yx_df)
  new_df$pvr_ESRBS_yx_r <- new_df$pvr_ESRBS_yx_t_value / sqrt(new_df$pvr_ESRBS_yx_t_value^2 + new_df$pvr_ESRBS_yx_df)
  new_df$pvr_ESRBS_yx_r[is.nan(new_df$pvr_ESRBS_yx_r)] <- 1
  
  minus_df <- new_df[ new_df$pvr_ESRBS_xy_est * new_df$pvr_ESRBS_yx_est >0,]
  add_df <-  new_df[ new_df$pvr_ESRBS_xy_est * new_df$pvr_ESRBS_yx_est <0,]
  
  minus_df$diff_r <- abs(minus_df$pvr_ESRBS_xy_r-minus_df$pvr_ESRBS_yx_r)
  add_df$diff_r <- abs(add_df$pvr_ESRBS_xy_r+add_df$pvr_ESRBS_yx_r)
  
  new_df <- rbind(minus_df,add_df)
  
  
  diff_df <- new_df[new_df[,"index"] %in% index,c("X","diff_r")]
  
  file_name <- paste0("./results/diff_cor/ESRRV_",name,".csv")
  write.csv(diff_df,file_name)
}  

stepwise_count_correct_conflict <- function(my_df,name){
  
  my_df$index <- c(1:8000)
  
  my_df$X <- as.factor(my_df$X)
  pvr_xy_p <- paste0("pvr_stepwise_xy_p")
  pvr_yx_p <- paste0("pvr_stepwise_yx_p")
  pvr_xy_est <- paste0("pvr_stepwise_xy_est")
  pvr_yx_est <- paste0("pvr_stepwise_yx_est")
  
  p_df <- my_df[c(my_df[,pvr_xy_p]<0.05 & my_df[,pvr_yx_p]>=0.05)|c(my_df[,pvr_xy_p]>=0.05 & my_df[,pvr_yx_p]<0.05)|
                  c((my_df[,pvr_xy_p]<0.05 & my_df[,pvr_yx_p]<0.05) & (my_df[,pvr_xy_est]*my_df[,pvr_yx_est]<0)),]
  
  
  index <- p_df$index
  
  new_df <- my_df[,c("X","index","pvr_stepwise_xy_p","pvr_stepwise_xy_est","pvr_stepwise_xy_npar",
                     "pvr_stepwise_yx_p","pvr_stepwise_yx_est","pvr_stepwise_yx_npar"
  )]
  
  colnames(new_df) <- c("X","index","pvr_stepwise_xy_p","pvr_stepwise_xy_est","pvr_stepwise_xy_npar",
                        "pvr_stepwise_yx_p","pvr_stepwise_yx_est","pvr_stepwise_yx_npar")
  
  new_df$pvr_stepwise_xy_df <- 128-new_df$pvr_stepwise_xy_npar-2
  new_df$pvr_stepwise_yx_df <- 128-new_df$pvr_stepwise_yx_npar-2
  
  
  new_df$pvr_stepwise_xy_t_value <- qt(1 - new_df$pvr_stepwise_xy_p / 2, new_df$pvr_stepwise_xy_df)
  new_df$pvr_stepwise_xy_r <- new_df$pvr_stepwise_xy_t_value / sqrt(new_df$pvr_stepwise_xy_t_value^2 + new_df$pvr_stepwise_xy_df)
  new_df$pvr_stepwise_xy_r[is.nan(new_df$pvr_stepwise_xy_r)] <- 1
  
  new_df$pvr_stepwise_yx_t_value <- qt(1 - new_df$pvr_stepwise_yx_p / 2, new_df$pvr_stepwise_yx_df)
  new_df$pvr_stepwise_yx_r <- new_df$pvr_stepwise_yx_t_value / sqrt(new_df$pvr_stepwise_yx_t_value^2 + new_df$pvr_stepwise_yx_df)
  new_df$pvr_stepwise_yx_r[is.nan(new_df$pvr_stepwise_yx_r)] <- 1
  
  minus_df <- new_df[ new_df$pvr_stepwise_xy_est * new_df$pvr_stepwise_yx_est >0,]
  add_df <-  new_df[ new_df$pvr_stepwise_xy_est * new_df$pvr_stepwise_yx_est <0,]
  
  minus_df$diff_r <- abs(minus_df$pvr_stepwise_xy_r-minus_df$pvr_stepwise_yx_r)
  add_df$diff_r <- abs(add_df$pvr_stepwise_xy_r+add_df$pvr_stepwise_yx_r)
  
  new_df <- rbind(minus_df,add_df)
  
  
  diff_df <- new_df[new_df[,"index"] %in% index,c("X","diff_r")]
  
  file_name <- paste0("./results/diff_cor/stepwise_",name,".csv")
  write.csv(diff_df,file_name)
}  

moran_count_correct_conflict <- function(my_df,name){
  
  my_df$index <- c(1:8000)
  
  my_df$X <- as.factor(my_df$X)
  pvr_xy_p <- paste0("pvr_moran_xy_p")
  pvr_yx_p <- paste0("pvr_moran_yx_p")
  pvr_xy_est <- paste0("pvr_moran_xy_est")
  pvr_yx_est <- paste0("pvr_moran_yx_est")
  
  p_df <- my_df[c(my_df[,pvr_xy_p]<0.05 & my_df[,pvr_yx_p]>=0.05)|c(my_df[,pvr_xy_p]>=0.05 & my_df[,pvr_yx_p]<0.05)|
                  c((my_df[,pvr_xy_p]<0.05 & my_df[,pvr_yx_p]<0.05) & (my_df[,pvr_xy_est]*my_df[,pvr_yx_est]<0)),]
  
  
  index <- p_df$index
  
  new_df <- my_df[,c("X","index","pvr_moran_xy_p","pvr_moran_xy_est","pvr_moran_xy_npar",
                     "pvr_moran_yx_p","pvr_moran_yx_est","pvr_moran_yx_npar"
  )]
  
  colnames(new_df) <- c("X","index","pvr_moran_xy_p","pvr_moran_xy_est","pvr_moran_xy_npar",
                        "pvr_moran_yx_p","pvr_moran_yx_est","pvr_moran_yx_npar")
  
  new_df$pvr_moran_xy_df <- 128-new_df$pvr_moran_xy_npar-2
  new_df$pvr_moran_yx_df <- 128-new_df$pvr_moran_yx_npar-2
  
  
  new_df$pvr_moran_xy_t_value <- qt(1 - new_df$pvr_moran_xy_p / 2, new_df$pvr_moran_xy_df)
  new_df$pvr_moran_xy_r <- new_df$pvr_moran_xy_t_value / sqrt(new_df$pvr_moran_xy_t_value^2 + new_df$pvr_moran_xy_df)
  new_df$pvr_moran_xy_r[is.nan(new_df$pvr_moran_xy_r)] <- 1
  
  new_df$pvr_moran_yx_t_value <- qt(1 - new_df$pvr_moran_yx_p / 2, new_df$pvr_moran_yx_df)
  new_df$pvr_moran_yx_r <- new_df$pvr_moran_yx_t_value / sqrt(new_df$pvr_moran_yx_t_value^2 + new_df$pvr_moran_yx_df)
  new_df$pvr_moran_yx_r[is.nan(new_df$pvr_moran_yx_r)] <- 1
  
  minus_df <- new_df[ new_df$pvr_moran_xy_est * new_df$pvr_moran_yx_est >0,]
  add_df <-  new_df[ new_df$pvr_moran_xy_est * new_df$pvr_moran_yx_est <0,]
  
  minus_df$diff_r <- abs(minus_df$pvr_moran_xy_r-minus_df$pvr_moran_yx_r)
  add_df$diff_r <- abs(add_df$pvr_moran_xy_r+add_df$pvr_moran_yx_r)
  
  new_df <- rbind(minus_df,add_df)
  
  
  diff_df <- new_df[new_df[,"index"] %in% index,c("X","diff_r")]
  
  file_name <- paste0("./results/diff_cor/moran_",name,".csv")
  write.csv(diff_df,file_name)
}  

ESRBS_count_correct_conflict(new_df1,"BM1_BM1+BM2")
ESRBS_count_correct_conflict(new_df2,"BM_BM+Norm")
ESRBS_count_correct_conflict(new_df3,"Norm_Norm+BM")
ESRBS_count_correct_conflict(new_df4,"Norm1_Norm1+Norm2")
ESRBS_count_correct_conflict(new_df5,"Shift")

stepwise_count_correct_conflict(new_df1,"BM1_BM1+BM2")
stepwise_count_correct_conflict(new_df2,"BM_BM+Norm")
stepwise_count_correct_conflict(new_df3,"Norm_Norm+BM")
stepwise_count_correct_conflict(new_df4,"Norm1_Norm1+Norm2")
stepwise_count_correct_conflict(new_df5,"Shift")

moran_count_correct_conflict(new_df1,"BM1_BM1+BM2")
moran_count_correct_conflict(new_df2,"BM_BM+Norm")
moran_count_correct_conflict(new_df3,"Norm_Norm+BM")
moran_count_correct_conflict(new_df4,"Norm1_Norm1+Norm2")
moran_count_correct_conflict(new_df5,"Shift")