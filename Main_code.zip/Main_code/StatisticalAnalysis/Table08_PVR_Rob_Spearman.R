library(ggplot2)
library(tidyr)


input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results3/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results3/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results3/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results3/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results3/final_csv/final.csv")


new_df1 <- read.csv(input_csv_1)
new_df2 <- read.csv(input_csv_2)
new_df3 <- read.csv(input_csv_3)
new_df4 <- read.csv(input_csv_4)
new_df5 <- read.csv(input_csv_5)


count_new_select <- function(my_df,estimator){
  my_df$X <- factor(my_df$X)
  
  ESRBS_p <- paste0("pvr_ESRBS_xy_",estimator,"_p")
  ESRBS_est <- paste0("pvr_ESRBS_xy_",estimator,"_est")
  
  moran_p <- paste0("pvr_moran_xy_",estimator,"_p")
  moran_est <- paste0("pvr_moran_xy_",estimator,"_est")
  
  
  new_method_ESRBS_correct <- my_df[(my_df[,ESRBS_p] < 0.05 & my_df$spearman_p < 0.05 & 
                                       my_df[,ESRBS_est] * my_df$spearman_est > 0) | 
                                      (my_df[,ESRBS_p] >= 0.05 & my_df$spearman_p >= 0.05), ]
  
  new_method_moran_correct <- my_df[(my_df[,moran_p]  < 0.05 & my_df$spearman_p < 0.05 & 
                                       my_df[,moran_est] * my_df$spearman_est > 0) | 
                                      (my_df[,moran_p] >= 0.05 & my_df$spearman_p >= 0.05), ]
  
  a <- table(new_method_ESRBS_correct$X)
  b <- table(new_method_moran_correct$X)
  return(list(a,b))
}

ESRBS_L2_1 <- count_new_select(new_df1,"L2")[[1]]
moran_L2_1 <- count_new_select(new_df1,"L2")[[2]]

ESRBS_L2_2 <- count_new_select(new_df2,"L2")[[1]]
moran_L2_2 <- count_new_select(new_df2,"L2")[[2]]

ESRBS_L2_3 <- count_new_select(new_df3,"L2")[[1]]
moran_L2_3 <- count_new_select(new_df3,"L2")[[2]]

ESRBS_L2_4 <- count_new_select(new_df4,"L2")[[1]]
moran_L2_4 <- count_new_select(new_df4,"L2")[[2]]

ESRBS_L2_5 <- count_new_select(new_df5,"L2")[[1]]
moran_L2_5 <- count_new_select(new_df5,"L2")[[2]]


ESRBS_L1_1 <- count_new_select(new_df1,"L1")[[1]]
moran_L1_1 <- count_new_select(new_df1,"L1")[[2]]

ESRBS_L1_2 <- count_new_select(new_df2,"L1")[[1]]
moran_L1_2 <- count_new_select(new_df2,"L1")[[2]]

ESRBS_L1_3 <- count_new_select(new_df3,"L1")[[1]]
moran_L1_3 <- count_new_select(new_df3,"L1")[[2]]

ESRBS_L1_4 <- count_new_select(new_df4,"L1")[[1]]
moran_L1_4 <- count_new_select(new_df4,"L1")[[2]]

ESRBS_L1_5 <- count_new_select(new_df5,"L1")[[1]]
moran_L1_5 <- count_new_select(new_df5,"L1")[[2]]


ESRBS_S_1 <- count_new_select(new_df1,"S")[[1]]
moran_S_1 <- count_new_select(new_df1,"S")[[2]]

ESRBS_S_2 <- count_new_select(new_df2,"S")[[1]]
moran_S_2 <- count_new_select(new_df2,"S")[[2]]

ESRBS_S_3 <- count_new_select(new_df3,"S")[[1]]
moran_S_3 <- count_new_select(new_df3,"S")[[2]]

ESRBS_S_4 <- count_new_select(new_df4,"S")[[1]]
moran_S_4 <- count_new_select(new_df4,"S")[[2]]

ESRBS_S_5 <- count_new_select(new_df5,"S")[[1]]
moran_S_5 <- count_new_select(new_df5,"S")[[2]]

ESRBS_M_1 <- count_new_select(new_df1,"M")[[1]]
moran_M_1 <- count_new_select(new_df1,"M")[[2]]

ESRBS_M_2 <- count_new_select(new_df2,"M")[[1]]
moran_M_2 <- count_new_select(new_df2,"M")[[2]]

ESRBS_M_3 <- count_new_select(new_df3,"M")[[1]]
moran_M_3 <- count_new_select(new_df3,"M")[[2]]

ESRBS_M_4 <- count_new_select(new_df4,"M")[[1]]
moran_M_4 <- count_new_select(new_df4,"M")[[2]]

ESRBS_M_5 <- count_new_select(new_df5,"M")[[1]]
moran_M_5 <- count_new_select(new_df5,"M")[[2]]


ESRBS_MM_1 <- count_new_select(new_df1,"MM")[[1]]
moran_MM_1 <- count_new_select(new_df1,"MM")[[2]]

ESRBS_MM_2 <- count_new_select(new_df2,"MM")[[1]]
moran_MM_2 <- count_new_select(new_df2,"MM")[[2]]

ESRBS_MM_3 <- count_new_select(new_df3,"MM")[[1]]
moran_MM_3 <- count_new_select(new_df3,"MM")[[2]]

ESRBS_MM_4 <- count_new_select(new_df4,"MM")[[1]]
moran_MM_4 <- count_new_select(new_df4,"MM")[[2]]

ESRBS_MM_5 <- count_new_select(new_df5,"MM")[[1]]
moran_MM_5 <- count_new_select(new_df5,"MM")[[2]]


res_df <- rbind(ESRBS_L2_1,
                ESRBS_L2_2,
                ESRBS_L2_3,
                ESRBS_L2_4,
                ESRBS_L2_5,

                ESRBS_L1_1,
                ESRBS_L1_2,
                ESRBS_L1_3,
                ESRBS_L1_4,
                ESRBS_L1_5,
                
                ESRBS_S_1,
                ESRBS_S_2,
                ESRBS_S_3,
                ESRBS_S_4,
                ESRBS_S_5,
                
                ESRBS_M_1,
                ESRBS_M_2,
                ESRBS_M_3,
                ESRBS_M_4,
                ESRBS_M_5,
                
                
                ESRBS_MM_1,
                ESRBS_MM_2,
                ESRBS_MM_3,
                ESRBS_MM_4,
                ESRBS_MM_5,

                moran_L2_1,
                moran_L2_2,
                moran_L2_3,
                moran_L2_4,
                moran_L2_5,
                
                moran_L1_1,
                moran_L1_2,
                moran_L1_3,
                moran_L1_4,
                moran_L1_5,
                
                moran_S_1,
                moran_S_2,
                moran_S_3,
                moran_S_4,
                moran_S_5,
                
                
                moran_M_1,
                moran_M_2,
                moran_M_3,
                moran_M_4,
                moran_M_5,
                
                moran_MM_1,
                moran_MM_2,
                moran_MM_3,
                moran_MM_4,
                moran_MM_5
                )

res_df <- as.data.frame(res_df)

res_df$estimator <- rep(c(rep("L2",5),rep("L1",5),rep("S",5),rep("M",5),rep("MM",5)),2)
res_df$method <- c(rep("ESRRV",25),rep("moran",25))
res_df$scenario <- rep(c("BM1_BM1+BM2","BM_BM+Norm",
                     "Norm_Norm+BM","Norm1_Norm1+Norm2","shift"),10)

write.csv(res_df,"results/06PVR_Rob_Spearman.csv")


