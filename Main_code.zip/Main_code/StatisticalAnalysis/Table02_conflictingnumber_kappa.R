library(ggplot2)
library(tidyr)
library(irr)


input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results01/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results01/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results01/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results01/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results01/final_csv/final.csv")

raw_df1 <- read.csv(input_csv_1)
raw_df2 <- read.csv(input_csv_2)
raw_df3 <- read.csv(input_csv_3)
raw_df4 <- read.csv(input_csv_4)
raw_df5 <- read.csv(input_csv_5)

split_posandneg <- function(my_df,method){
  my_df$X <- as.factor(my_df$X)
  pvr_xy_p <- paste0("pvr_",method,"_xy_p")
  pvr_yx_p <- paste0("pvr_",method,"_yx_p")
  pvr_xy_est <- paste0("pvr_",method,"_xy_est")
  pvr_yx_est <- paste0("pvr_",method,"_yx_est")
  
  
  new_df <- my_df[,c("X",pvr_xy_est,pvr_xy_p,pvr_yx_est,pvr_yx_p)]
  
  new_df$label_xy <- 0
  new_df$label_yx <- 0
  
  new_df[new_df[,pvr_xy_est] > 0 & new_df[,pvr_xy_p] < 0.05, "label_xy"] <- 1
  new_df[new_df[,pvr_yx_est] > 0 & new_df[,pvr_yx_p] < 0.05, "label_yx"] <- 1
  
  A <- length(rownames(new_df[new_df$label_xy == 1 & new_df$label_yx == 1 ,]))
  B <- length(rownames(new_df[new_df$label_xy == 1 & new_df$label_yx == 0 ,]))
  C <- length(rownames(new_df[new_df$label_xy == 0 & new_df$label_yx == 1 ,]))
  D <- length(rownames(new_df[new_df$label_xy == 0 & new_df$label_yx == 0 ,]))
  
  
  #p <- mcnemar.exact(matrix(c(A,B,C,D),nrow=2))$p.value
  p <- kappa2(new_df[,c("label_xy","label_yx")], weight="unweighted")
  
  res <- c(p$value,p$p.value)
  return(res)
}

ESRRV1 <- split_posandneg(raw_df1,"ESRBS")
ESRRV2 <- split_posandneg(raw_df2,"ESRBS")
ESRRV3 <- split_posandneg(raw_df3,"ESRBS")
ESRRV4 <- split_posandneg(raw_df4,"ESRBS")
ESRRV5 <- split_posandneg(raw_df5,"ESRBS")

stepwise1 <- split_posandneg(raw_df1,"stepwise")
stepwise2 <- split_posandneg(raw_df2,"stepwise")
stepwise3 <- split_posandneg(raw_df3,"stepwise")
stepwise4 <- split_posandneg(raw_df4,"stepwise")
stepwise5 <- split_posandneg(raw_df5,"stepwise")

moran1 <- split_posandneg(raw_df1,"moran")
moran2 <- split_posandneg(raw_df2,"moran")
moran3 <- split_posandneg(raw_df3,"moran")
moran4 <- split_posandneg(raw_df4,"moran")
moran5 <- split_posandneg(raw_df5,"moran")

res_df <- rbind(ESRRV1,ESRRV2,ESRRV3,ESRRV4,ESRRV5,
                stepwise1,stepwise2,stepwise3,stepwise4,stepwise5,
                moran1,moran2,moran3,moran4,moran5)

res_df <- as.data.frame(res_df)

res_df$scenario <- rep(c("BM1&BM1+BM2","BM&BM+Norm","Norm&Norm+BM","Norm1&Norm1+Norm2","Shift"),3)
res_df$method <- c(rep("ESRRV",5),rep("mAIC",5),rep("mMorI",5))

res_df <- as.data.frame(res_df)
write.csv(res_df,"results_Spearman/01_02Conflicting_cohens_kappa.csv")
