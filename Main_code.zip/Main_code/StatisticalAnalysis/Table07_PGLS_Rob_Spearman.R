library(ggplot2)
library(tidyr)

input_csv_1 <- paste0("../BM1_BM1+BM2/01analysis/results5/final_csv/final.csv")
input_csv_2 <- paste0("../BM_BM+Norm/01analysis/results5/final_csv/final.csv")
input_csv_3 <- paste0("../Norm_Norm+BM/01analysis/results5/final_csv/final.csv")
input_csv_4 <- paste0("../Norm1_Norm1+Norm2/01analysis/results5/final_csv/final.csv")
input_csv_5 <- paste0("../shift/01analysis/results5/final_csv/final.csv")

new_df1 <- read.csv(input_csv_1)
new_df2 <- read.csv(input_csv_2)
new_df3 <- read.csv(input_csv_3)
new_df4 <- read.csv(input_csv_4)
new_df5 <- read.csv(input_csv_5)


count_new_select <- function(my_df,estimator){
  my_df$X <- factor(my_df$X)
  
  PIC_p <- paste0("PIC_",estimator,"_xy_p_vec")
  PIC_est <- paste0("PIC_",estimator,"_xy_est_vec")
  
  PGLS_p <- paste0("PGLS_",estimator,"_xy_p_vec")
  PGLS_est <- paste0("PGLS_",estimator,"_xy_est_vec")
  
  
  new_method_PIC_correct <- my_df[(my_df[,PIC_p] < 0.05 & my_df$spearman_p < 0.05 & 
                                       my_df[,PIC_est] * my_df$spearman_est > 0) | 
                                      (my_df[,PIC_p] >= 0.05 & my_df$spearman_p >= 0.05), ]
  
  new_method_PGLS_correct <- my_df[(my_df[,PGLS_p]  < 0.05 & my_df$spearman_p < 0.05 & 
                                       my_df[,PGLS_est] * my_df$spearman_est > 0) | 
                                      (my_df[,PGLS_p] >= 0.05 & my_df$spearman_p >= 0.05), ]
  
  a <- table(new_method_PIC_correct$X)
  b <- table(new_method_PGLS_correct$X)
  return(list(a,b))
}

PIC_L2_1 <- count_new_select(new_df1,"L2")[[1]]
PGLS_L2_1 <- count_new_select(new_df1,"L2")[[2]]

PIC_L2_2 <- count_new_select(new_df2,"L2")[[1]]
PGLS_L2_2 <- count_new_select(new_df2,"L2")[[2]]

PIC_L2_3 <- count_new_select(new_df3,"L2")[[1]]
PGLS_L2_3 <- count_new_select(new_df3,"L2")[[2]]

PIC_L2_4 <- count_new_select(new_df4,"L2")[[1]]
PGLS_L2_4 <- count_new_select(new_df4,"L2")[[2]]

PIC_L2_5 <- count_new_select(new_df5,"L2")[[1]]
PGLS_L2_5 <- count_new_select(new_df5,"L2")[[2]]

PIC_L1_1 <- count_new_select(new_df1,"L1")[[1]]
PGLS_L1_1 <- count_new_select(new_df1,"L1")[[2]]

PIC_L1_2 <- count_new_select(new_df2,"L1")[[1]]
PGLS_L1_2 <- count_new_select(new_df2,"L1")[[2]]

PIC_L1_3 <- count_new_select(new_df3,"L1")[[1]]
PGLS_L1_3 <- count_new_select(new_df3,"L1")[[2]]

PIC_L1_4 <- count_new_select(new_df4,"L1")[[1]]
PGLS_L1_4 <- count_new_select(new_df4,"L1")[[2]]

PIC_L1_5 <- count_new_select(new_df5,"L1")[[1]]
PGLS_L1_5 <- count_new_select(new_df5,"L1")[[2]]

PIC_S_1 <- count_new_select(new_df1,"S")[[1]]
PGLS_S_1 <- count_new_select(new_df1,"S")[[2]]

PIC_S_2 <- count_new_select(new_df2,"S")[[1]]
PGLS_S_2 <- count_new_select(new_df2,"S")[[2]]

PIC_S_3 <- count_new_select(new_df3,"S")[[1]]
PGLS_S_3 <- count_new_select(new_df3,"S")[[2]]

PIC_S_4 <- count_new_select(new_df4,"S")[[1]]
PGLS_S_4 <- count_new_select(new_df4,"S")[[2]]

PIC_S_5 <- count_new_select(new_df5,"S")[[1]]
PGLS_S_5 <- count_new_select(new_df5,"S")[[2]]

PIC_M_1 <- count_new_select(new_df1,"M")[[1]]
PGLS_M_1 <- count_new_select(new_df1,"M")[[2]]

PIC_M_2 <- count_new_select(new_df2,"M")[[1]]
PGLS_M_2 <- count_new_select(new_df2,"M")[[2]]

PIC_M_3 <- count_new_select(new_df3,"M")[[1]]
PGLS_M_3 <- count_new_select(new_df3,"M")[[2]]

PIC_M_4 <- count_new_select(new_df4,"M")[[1]]
PGLS_M_4 <- count_new_select(new_df4,"M")[[2]]

PIC_M_5 <- count_new_select(new_df5,"M")[[1]]
PGLS_M_5 <- count_new_select(new_df5,"M")[[2]]


PIC_MM_1 <- count_new_select(new_df1,"MM")[[1]]
PGLS_MM_1 <- count_new_select(new_df1,"MM")[[2]]

PIC_MM_2 <- count_new_select(new_df2,"MM")[[1]]
PGLS_MM_2 <- count_new_select(new_df2,"MM")[[2]]

PIC_MM_3 <- count_new_select(new_df3,"MM")[[1]]
PGLS_MM_3 <- count_new_select(new_df3,"MM")[[2]]

PIC_MM_4 <- count_new_select(new_df4,"MM")[[1]]
PGLS_MM_4 <- count_new_select(new_df4,"MM")[[2]]

PIC_MM_5 <- count_new_select(new_df5,"MM")[[1]]
PGLS_MM_5 <- count_new_select(new_df5,"MM")[[2]]

res_df <- rbind(PIC_L2_1,
                PIC_L2_2,
                PIC_L2_3,
                PIC_L2_4,
                PIC_L2_5,
                
                PIC_L1_1,
                PIC_L1_2,
                PIC_L1_3,
                PIC_L1_4,
                PIC_L1_5,
                
                PIC_S_1,
                PIC_S_2,
                PIC_S_3,
                PIC_S_4,
                PIC_S_5,
                
                PIC_M_1,
                PIC_M_2,
                PIC_M_3,
                PIC_M_4,
                PIC_M_5,
                
                
                PIC_MM_1,
                PIC_MM_2,
                PIC_MM_3,
                PIC_MM_4,
                PIC_MM_5,

                PGLS_L2_1,
                PGLS_L2_2,
                PGLS_L2_3,
                PGLS_L2_4,
                PGLS_L2_5,
                
                PGLS_L1_1,
                PGLS_L1_2,
                PGLS_L1_3,
                PGLS_L1_4,
                PGLS_L1_5,
                
                PGLS_S_1,
                PGLS_S_2,
                PGLS_S_3,
                PGLS_S_4,
                PGLS_S_5,
                
                
                PGLS_M_1,
                PGLS_M_2,
                PGLS_M_3,
                PGLS_M_4,
                PGLS_M_5,
                
                
                PGLS_MM_1,
                PGLS_MM_2,
                PGLS_MM_3,
                PGLS_MM_4,
                PGLS_MM_5
                )

res_df <- as.data.frame(res_df)

res_df$estimator <- rep(c(rep("L2",5),rep("L1",5),rep("S",5),rep("M",5),rep("MM",5)),2)
res_df$method <- c(rep("PIC",25),rep("PGLS",25))
res_df$scenario <- rep(c("BM1_BM1+BM2","BM_BM+Norm",
                         "Norm_Norm+BM","Norm1_Norm1+Norm2","shift"),10)

write.csv(res_df,"results/06PGLS_Rob_Spearman.csv")
