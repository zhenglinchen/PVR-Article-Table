
library(ape)
library(geiger)
library(ggplot2)
library(phytools)
args <- commandArgs()
simulate.seed <- args[6]
set.seed(1)

# parameters = A data.frame with only one row and eight columns, the names of columns are all parameters setting to run the simulation
PAR1 <- expand.grid(diff_sd = c(0.01,0.1,1,2,4,8,16,32),
                    n1.spp = c(64), 
                    n2.spp = c(64),
                    n.spp = c(128), # Number of species in the phylogenetic tree and in the dataset
                    feature_num = 2) 

creat_tree <- function(n1,n2){
  set.seed(1)
  tips_num <- n1+n2
  final_tr <- stree(tips_num, type = "right")
  n <- nrow(final_tr$edge) / 2
  decreasing_seq <- seq(from=5, to=0,length.out = n+1)
  used_seq <- rev(decreasing_seq[-length(decreasing_seq)])
  unit_seq <- -diff(decreasing_seq)
  result <- c(unit_seq,used_seq)
  final_tr$edge.length <- result
  return(final_tr)
}

#parameters <- PAR1[1,]
my_tree <- creat_tree(64,64)

g