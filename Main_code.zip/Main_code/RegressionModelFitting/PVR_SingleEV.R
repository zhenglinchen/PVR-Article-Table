
command <- paste0("ls data01 | wc -l")
system(command)
args <- commandArgs(trailingOnly = TRUE)
library(ape)
library(car)
library(PVR)
library(MASS)

index_num <- 8

my_moran <- function(x, phy=my_tree, trait=NULL, sig = TRUE, sig.t = 0.05, MI.t = 0.05){
  pvr <- x@Eigen$vectors
  model_pre_eigenvectors <- NULL
  tmpTrait <- trait
  model_eigenvectors <- NULL
  model_EV <- NULL
  W <- 1/cophenetic(my_tree)
  diag(W) <- 0
  
  ORIRes <- Moran.I(trait, weight = W, alternative = "two.sided")
  ORIRes_p <- round(ORIRes$p.value, 5)
  ORIRes_I <- ORIRes$observed
  if (ORIRes_p > 0.05 | (ORIRes_p < 0.05 & ORIRes_I < 0)){
    return(model_EV)
  }else{
    for (k in 1:(ncol(pvr)-1)){
      all_EV <- colnames(pvr)
      tmpRes <- matrix(nrow = length(all_EV), ncol = 2) 
      
      for (i in 1:length(all_EV)){
        new_eigenvector <- pvr[,all_EV[i]]
        
        if (is.null(model_pre_eigenvectors)) {
          model_eigenvectors <- new_eigenvector
        } else {
          model_eigenvectors <- cbind(model_pre_eigenvectors, new_eigenvector)
        }
        
        tmpLM <- lm(tmpTrait ~ model_eigenvectors)
        tmpMI <- Moran.I(tmpLM$residuals, weight = W, alternative = "two.sided")
        tmpRes[i, 1] <- round(tmpMI$p.value, 5)
        tmpRes[i, 2] <- tmpMI$observed
      }
      
      idx <- which(tmpRes[,2] == min(tmpRes[,2]))
      
      selected_EV <- all_EV[idx]
      selected_eigenvector <- pvr[,selected_EV]
      all_EV <- all_EV[-idx]
      pvr <- pvr[,!colnames(pvr) %in% selected_EV]
      
      if (is.null(model_pre_eigenvectors)) {
        
        model_pre_eigenvectors <- selected_eigenvector
        model_EV <- selected_EV
      } else {
        model_pre_eigenvectors <- cbind(model_pre_eigenvectors, selected_eigenvector)
        model_EV <- c(model_EV, selected_EV)
      } 
      
      if (tmpRes[idx,1] > 0.05 | (tmpRes[idx,1] < 0.05 & tmpRes[idx,2] < 0)){
        break
      }
      
      k <- k + 1
      
    }
    
    #model_pre_eigenvectors
    return(model_EV)
    
  }
  
}

get_history_change <- function(all_df,relation_df,X){
  L <- length(rownames(relation_df))
  res_vec <- NULL
  for(i in c(1:L)){
    parent <- relation_df$Parent[i]
    child <- relation_df$Child[i]
    parent_trait_X <- all_df[all_df$ID==parent,X]
    child_trait_X <- all_df[all_df$ID==child,X]
    change_X <- (child_trait_X - parent_trait_X)/relation_df$distance[i]
    res_vec <- c(res_vec,change_X)
  }  
  return(res_vec)
}

get_corelated_var <- function(y,pvr_df,my_tree){
  c_num <- length(my_tree$tip.label)-1
  EV_vec <- NULL
  for (c in c(1:c_num)){
    col_name <- paste("c",c,sep="")
    norm_p_y <- shapiro.test(pvr_df[,y])$p.value
    norm_p_EV <- shapiro.test(pvr_df[,col_name])$p.value
    if (norm_p_y>=0.05 & norm_p_EV>=0.05){
      fit <- cor.test(pvr_df[,y],pvr_df[,col_name],method="pearson")
    }else{
      fit <- cor.test(pvr_df[,y],pvr_df[,col_name],method="spearman")
    }
    if (fit$p.value<0.05){
      EV_vec <- c(EV_vec,col_name)
    }
  }
  return(EV_vec)
}



#### 1. define NULL vector #####
sig_label_vec <- NULL

pvr_ESRBS_xy_est_vec <- NULL
pvr_ESRBS_xy_p_vec <- NULL
pvr_ESRBS_xy_aic_vec <- NULL
pvr_ESRBS_xy_rsq_vec <- NULL
pvr_ESRBS_xy_npar_vec <- NULL
pvr_ESRBS_xy_EV_vec <- NULL
pvr_ESRBS_xy_norm_p_n_vec <- NULL
pvr_ESRBS_xy_vif_vec <- NULL

pvr_ESRBS_yx_est_vec <- NULL
pvr_ESRBS_yx_p_vec <- NULL
pvr_ESRBS_yx_aic_vec <- NULL
pvr_ESRBS_yx_rsq_vec <- NULL
pvr_ESRBS_yx_npar_vec <- NULL
pvr_ESRBS_yx_EV_vec <- NULL
pvr_ESRBS_yx_norm_p_n_vec <- NULL
pvr_ESRBS_yx_vif_vec <- NULL

pvr_stepwise_xy_est_vec <- NULL
pvr_stepwise_xy_p_vec <- NULL
pvr_stepwise_xy_aic_vec <- NULL
pvr_stepwise_xy_rsq_vec <- NULL
pvr_stepwise_xy_npar_vec <- NULL
pvr_stepwise_xy_EV_vec <- NULL
pvr_stepwise_xy_vif_vec <- NULL

pvr_stepwise_yx_est_vec <- NULL
pvr_stepwise_yx_p_vec <- NULL
pvr_stepwise_yx_aic_vec <- NULL
pvr_stepwise_yx_rsq_vec <- NULL
pvr_stepwise_yx_npar_vec <- NULL
pvr_stepwise_yx_EV_vec <- NULL
pvr_stepwise_yx_vif_vec <- NULL

pvr_moran_xy_est_vec <- NULL
pvr_moran_xy_p_vec <- NULL
pvr_moran_xy_aic_vec <- NULL
pvr_moran_xy_rsq_vec <- NULL
pvr_moran_xy_npar_vec <- NULL
pvr_moran_xy_EV_vec <- NULL
pvr_moran_xy_vif_vec <- NULL


pvr_moran_yx_est_vec <- NULL
pvr_moran_yx_p_vec <- NULL
pvr_moran_yx_aic_vec <- NULL
pvr_moran_yx_rsq_vec <- NULL
pvr_moran_yx_npar_vec <- NULL
pvr_moran_yx_EV_vec <- NULL
pvr_moran_yx_vif_vec <- NULL


#### 2. batch process ####
for (index in c(1:index_num)){
  sig_label <- "O"
  tips_df_file <- paste0("data01/",index,"/tips_states.csv")
  all_df_file <- paste0("data01/",index,"/all_states.csv")
  relation_file <- paste0("data01/",index,"/Parent2Child.txt")
  my_tree_file <- paste0("data01/",index,"/mytree.nwk")
  relation_df <- read.table(relation_file,sep = " ",header = T)
  all_df <- read.csv(all_df_file)
  tips_df <- read.csv(tips_df_file)
  my_tree <- read.tree(my_tree_file)
  
  tips_num <- length(tips_df$ID)
  relation_df$distance <- my_tree$edge.length
  
  #### 2.4 PVR  ####
  ### decompose the tree to PVRs ##
  x <- PVR::PVRdecomp(my_tree)
  pvrs <- x@Eigen$vectors
  pvr_df <- cbind(tips_df,pvrs)
  
  colnames(pvrs) <- paste0("c",c(1:dim(pvrs)[2]))
  c_num <- length(my_tree$tip.label)-1
  formula_list <- NULL
  
  
  ##### 2.4.1  ESRRV ####
  pvr_name_X1 <- get_corelated_var("X1",pvr_df,my_tree)
  pvr_name_X2 <- get_corelated_var("X2",pvr_df,my_tree)
  
  pvr_ESRBS_xy_npar <- length(pvr_name_X1)
  pvr_ESRBS_yx_npar <- length(pvr_name_X2)
  EV_xy_normal_p_vec <- NULL
  EV_yx_normal_p_vec <- NULL
  pvr_ESRBS_xy_norm_p_n <- 0
  pvr_ESRBS_yx_norm_p_n <- 0
  
  if (pvr_ESRBS_xy_npar==0){
    xy_pvr_formula <- as.formula(paste0("X1~X2"))
    pvr_ESRBS_xy_EV <- c("0")
    pvr_ESRBS_xy_norm_p_n <- 0
    pvr_ESRBS_xy_vif <- 0
  }else{
    consider_xy_pvr <- paste(sort(pvr_name_X1),collapse="+")
    xy_pvr_formula <- as.formula(paste0("X1~X2+",consider_xy_pvr))
    pvr_ESRBS_xy_EV <- consider_xy_pvr
    pvr_ESRBS_xy_lm <- lm(xy_pvr_formula,data=pvr_df)
    pvr_ESRBS_xy_vif <- car::vif(pvr_ESRBS_xy_lm)[1]
    for (vec in pvr_name_X1){
      EV_xy_normal_p <- shapiro.test(pvr_df[,vec])$p.value
      EV_xy_normal_p_vec <- c(EV_xy_normal_p_vec,EV_xy_normal_p)
    }
    pvr_ESRBS_xy_norm_p_n <- sum(EV_xy_normal_p_vec>=0.05)
  }
  
  if (pvr_ESRBS_yx_npar==0){
    yx_pvr_formula <- as.formula(paste0("X2~X1"))
    pvr_ESRBS_yx_EV <- c("0")
    pvr_ESRBS_yx_norm_p_n <- 0
    pvr_ESRBS_yx_vif <- 0
  }else{
    consider_yx_pvr <- paste(sort(pvr_name_X2),collapse="+")
    yx_pvr_formula <- as.formula(paste0("X2~X1+",consider_yx_pvr))
    pvr_ESRBS_yx_EV <- consider_yx_pvr
    pvr_ESRBS_yx_lm <- lm(yx_pvr_formula,data=pvr_df)
    pvr_ESRBS_yx_vif <- car::vif(pvr_ESRBS_yx_lm)[1]
    for (vec in pvr_name_X2){
      EV_yx_normal_p <- shapiro.test(pvr_df[,vec])$p.value
      EV_yx_normal_p_vec <- c(EV_yx_normal_p_vec,EV_yx_normal_p)
    }
    pvr_ESRBS_yx_norm_p_n <- sum(EV_yx_normal_p_vec>=0.05)
  }
  
  pvr_ESRBS_xy_lm <- lm(xy_pvr_formula,data=pvr_df)
  pvr_ESRBS_yx_lm <- lm(yx_pvr_formula,data=pvr_df)
  
  pvr_ESRBS_xy_est <- summary(pvr_ESRBS_xy_lm)$coefficients[2,1]
  pvr_ESRBS_xy_p <- summary(pvr_ESRBS_xy_lm)$coefficients[2,4]
  pvr_ESRBS_xy_aic <- AIC(pvr_ESRBS_xy_lm,k=pvr_ESRBS_xy_npar+1)
  pvr_ESRBS_xy_rsq <- summary(pvr_ESRBS_xy_lm)$r.squared
  
  pvr_ESRBS_yx_est <- summary(pvr_ESRBS_yx_lm)$coefficients[2,1]
  pvr_ESRBS_yx_p <- summary(pvr_ESRBS_yx_lm)$coefficients[2,4]
  pvr_ESRBS_yx_aic <- AIC(pvr_ESRBS_yx_lm,k=pvr_ESRBS_yx_npar+1)
  pvr_ESRBS_yx_rsq <- summary(pvr_ESRBS_yx_lm)$r.squared

  
  ##### 2.4.2  STEPWISE ####
  step_df <- cbind(tips_df,pvrs)
  pvr_step_xy_lm <- lm(X1~.,data = step_df[,c(2,4:100)])
  pvr_step_yx_lm <- lm(X2~.,data = step_df[,c(3:100)])
  pvr_xy_STEPWISE <- stepAIC(pvr_step_xy_lm,direction = "both",trace = FALSE)
  pvr_yx_STEPWISE <- stepAIC(pvr_step_yx_lm,direction = "both",trace = FALSE)
  
  pvr_xy_selected_vectors <- colnames(pvr_xy_STEPWISE$qr$qr)[-1]
  pvr_yx_selected_vectors <- colnames(pvr_yx_STEPWISE$qr$qr)[-1]
  
  pvr_stepwise_xy_npar <- length(pvr_xy_selected_vectors[-1])
  pvr_stepwise_yx_npar <- length(pvr_yx_selected_vectors[-1])
  
  if (pvr_stepwise_xy_npar==0){
    xy_pvr_formula <- as.formula(paste0("X1~X2"))
    pvr_stepwise_xy_EV <- c("0")
    pvr_stepwise_xy_vif <- 0
    
    
  }else{
    consider_xy_pvr <- paste(sort(pvr_xy_selected_vectors[-1]),collapse="+")
    xy_pvr_formula <- as.formula(paste0("X1~X2+",consider_xy_pvr))
    pvr_stepwise_xy_EV <- consider_xy_pvr
    pvr_stepwise_xy_lm <- lm(xy_pvr_formula,data = step_df)

    pvr_stepwise_xy_vif <- car::vif(pvr_stepwise_xy_lm)[1]
    
  }
  
  if (pvr_stepwise_yx_npar==0){
    yx_pvr_formula <- as.formula(paste0("X2~X1"))
    pvr_stepwise_yx_EV <- c("0")
    pvr_stepwise_yx_vif <- 0
    
  }else{
    consider_yx_pvr <- paste(sort(pvr_yx_selected_vectors[-1]),collapse="+")
    yx_pvr_formula <- as.formula(paste0("X2~X1+",consider_yx_pvr))
    pvr_stepwise_yx_EV <- consider_yx_pvr
    pvr_stepwise_yx_lm <- lm(yx_pvr_formula,data = step_df)
    pvr_stepwise_yx_vif <- car::vif(pvr_stepwise_yx_lm)[1]
    
  }
  
  pvr_stepwise_xy_lm <- lm(xy_pvr_formula,data = step_df)
  pvr_stepwise_yx_lm <- lm(yx_pvr_formula,data = step_df)
  
  pvr_stepwise_xy_npar <- length(colnames(pvr_xy_STEPWISE$qr$qr))-1
  pvr_stepwise_xy_est <- summary(pvr_stepwise_xy_lm)$coefficients[2,1]
  pvr_stepwise_xy_p <- summary(pvr_stepwise_xy_lm)$coefficients[2,4]
  pvr_stepwise_xy_aic <- AIC(pvr_stepwise_xy_lm,k=pvr_stepwise_xy_npar+1)
  pvr_stepwise_xy_rsq <- summary(pvr_stepwise_xy_lm)$r.squared

  
  pvr_stepwise_yx_npar <- length(colnames(pvr_yx_STEPWISE$qr$qr))-1
  pvr_stepwise_yx_est <- summary(pvr_stepwise_yx_lm)$coefficients[2,1]
  pvr_stepwise_yx_p <- summary(pvr_stepwise_yx_lm)$coefficients[2,4]
  pvr_stepwise_yx_aic <- AIC(pvr_stepwise_yx_lm,k=pvr_stepwise_yx_npar+1)
  pvr_stepwise_yx_rsq <- summary(pvr_stepwise_yx_lm)$r.squared

  
  
  ##### 2.4.3  moran's I ####
  pvr_moran_xy <- my_moran(x,trait = tips_df[,"X1"],phy = my_tree)
  pvr_moran_yx <- my_moran(x,trait = tips_df[,"X2"],phy = my_tree)
  
  pvr_moran_xy_npar <- length(pvr_moran_xy)
  pvr_moran_yx_npar <- length(pvr_moran_yx)
  
  if (pvr_moran_xy_npar==0){
    xy_pvr_formula <- as.formula(paste0("X1~X2"))
    pvr_moran_xy_EV <- c("0")
    pvr_moran_xy_vif <- 0
  }else{
    consider_xy_pvr <- paste(sort(pvr_moran_xy),collapse="+")
    xy_pvr_formula <- as.formula(paste0("X1~X2+",consider_xy_pvr))
    pvr_moran_xy_EV <- consider_xy_pvr
    pvr_moran_xy_lm <- lm(xy_pvr_formula,data = step_df)

    pvr_moran_xy_vif <- car::vif(pvr_moran_xy_lm)[1]
  }
  
  if (pvr_moran_yx_npar==0){
    yx_pvr_formula <- as.formula(paste0("X2~X1"))
    pvr_moran_yx_EV <- c("0")
    pvr_moran_yx_vif <- 0
  }else{
    consider_yx_pvr <- paste(sort(pvr_moran_yx),collapse="+")
    yx_pvr_formula <- as.formula(paste0("X2~X1+",consider_yx_pvr))
    pvr_moran_yx_EV <- consider_yx_pvr
    pvr_moran_yx_lm <- lm(yx_pvr_formula,data = step_df)
    pvr_moran_yx_vif <- car::vif(pvr_moran_yx_lm)[1]
  }
  
  pvr_moran_xy_lm <- lm(xy_pvr_formula,data = step_df)
  pvr_moran_yx_lm <- lm(yx_pvr_formula,data = step_df)  

  
  pvr_moran_xy_est <- summary(pvr_moran_xy_lm)$coefficients[2,1]
  pvr_moran_xy_p <- summary(pvr_moran_xy_lm)$coefficients[2,4]
  pvr_moran_xy_aic <- AIC(pvr_moran_xy_lm,k=pvr_moran_xy_npar+1)
  pvr_moran_xy_rsq <- summary(pvr_moran_xy_lm)$r.squared

  
  pvr_moran_yx_est <- summary(pvr_moran_yx_lm)$coefficients[2,1]
  pvr_moran_yx_p <- summary(pvr_moran_yx_lm)$coefficients[2,4]
  pvr_moran_yx_aic <- AIC(pvr_moran_yx_lm,k=pvr_moran_yx_npar+1)
  pvr_moran_yx_rsq <- summary(pvr_moran_yx_lm)$r.squared
  
  
  #### 2.7 add results #####
  ##### 2.7.2 PVR results add. #####
  
  ### ESRRV add ##
  pvr_ESRBS_xy_est_vec <- c(pvr_ESRBS_xy_est_vec,pvr_ESRBS_xy_est)
  pvr_ESRBS_xy_p_vec <- c(pvr_ESRBS_xy_p_vec,pvr_ESRBS_xy_p)
  pvr_ESRBS_xy_aic_vec <- c(pvr_ESRBS_xy_aic_vec,pvr_ESRBS_xy_aic)
  pvr_ESRBS_xy_rsq_vec <- c(pvr_ESRBS_xy_rsq_vec,pvr_ESRBS_xy_rsq)
  pvr_ESRBS_xy_npar_vec <- c(pvr_ESRBS_xy_npar_vec,pvr_ESRBS_xy_npar)
  pvr_ESRBS_xy_EV_vec <- c(pvr_ESRBS_xy_EV_vec,pvr_ESRBS_xy_EV)
  pvr_ESRBS_xy_norm_p_n_vec <- c(pvr_ESRBS_xy_norm_p_n_vec,pvr_ESRBS_xy_norm_p_n)
  pvr_ESRBS_xy_vif_vec <- c(pvr_ESRBS_xy_vif_vec,pvr_ESRBS_xy_vif)
  
  pvr_ESRBS_yx_est_vec <- c(pvr_ESRBS_yx_est_vec,pvr_ESRBS_yx_est)
  pvr_ESRBS_yx_p_vec <- c(pvr_ESRBS_yx_p_vec,pvr_ESRBS_yx_p)
  pvr_ESRBS_yx_aic_vec <- c(pvr_ESRBS_yx_aic_vec,pvr_ESRBS_yx_aic)
  pvr_ESRBS_yx_rsq_vec <- c(pvr_ESRBS_yx_rsq_vec,pvr_ESRBS_yx_rsq)
  pvr_ESRBS_yx_npar_vec <- c(pvr_ESRBS_yx_npar_vec,pvr_ESRBS_yx_npar)
  pvr_ESRBS_yx_EV_vec <- c(pvr_ESRBS_yx_EV_vec,pvr_ESRBS_yx_EV)
  pvr_ESRBS_yx_norm_p_n_vec <- c(pvr_ESRBS_yx_norm_p_n_vec,pvr_ESRBS_yx_norm_p_n)
  pvr_ESRBS_yx_vif_vec <- c(pvr_ESRBS_yx_vif_vec,pvr_ESRBS_yx_vif)
  
  ## stepwise add. ##
  pvr_stepwise_xy_est_vec <- c(pvr_stepwise_xy_est_vec,pvr_stepwise_xy_est)
  pvr_stepwise_xy_p_vec <- c(pvr_stepwise_xy_p_vec,pvr_stepwise_xy_p)
  pvr_stepwise_xy_aic_vec <- c(pvr_stepwise_xy_aic_vec,pvr_stepwise_xy_aic)
  pvr_stepwise_xy_rsq_vec <- c(pvr_stepwise_xy_rsq_vec,pvr_stepwise_xy_rsq)
  pvr_stepwise_xy_npar_vec <- c(pvr_stepwise_xy_npar_vec,pvr_stepwise_xy_npar)
  pvr_stepwise_xy_EV_vec <- c(pvr_stepwise_xy_EV_vec,pvr_stepwise_xy_EV)
  pvr_stepwise_xy_vif_vec <- c(pvr_stepwise_xy_vif_vec,pvr_stepwise_xy_vif)
  
  pvr_stepwise_yx_est_vec <- c(pvr_stepwise_yx_est_vec,pvr_stepwise_yx_est)
  pvr_stepwise_yx_p_vec <- c(pvr_stepwise_yx_p_vec,pvr_stepwise_yx_p)
  pvr_stepwise_yx_aic_vec <- c(pvr_stepwise_yx_aic_vec,pvr_stepwise_yx_aic)
  pvr_stepwise_yx_rsq_vec <- c(pvr_stepwise_yx_rsq_vec,pvr_stepwise_yx_rsq)
  pvr_stepwise_yx_npar_vec <- c(pvr_stepwise_yx_npar_vec,pvr_stepwise_yx_npar)
  pvr_stepwise_yx_EV_vec <- c(pvr_stepwise_yx_EV_vec,pvr_stepwise_yx_EV)
  pvr_stepwise_yx_vif_vec <- c(pvr_stepwise_yx_vif_vec,pvr_stepwise_yx_vif)
  
  ## moran's I add ##
  pvr_moran_xy_est_vec <- c(pvr_moran_xy_est_vec,pvr_moran_xy_est)
  pvr_moran_xy_p_vec <- c(pvr_moran_xy_p_vec,pvr_moran_xy_p)
  pvr_moran_xy_aic_vec <- c(pvr_moran_xy_aic_vec,pvr_moran_xy_aic)
  pvr_moran_xy_rsq_vec <- c(pvr_moran_xy_rsq_vec,pvr_moran_xy_rsq)
  pvr_moran_xy_npar_vec <- c(pvr_moran_xy_npar_vec,pvr_moran_xy_npar)
  pvr_moran_xy_EV_vec <- c(pvr_moran_xy_EV_vec,pvr_moran_xy_EV)
  pvr_moran_xy_vif_vec <- c(pvr_moran_xy_vif_vec,pvr_moran_xy_vif)
  
  pvr_moran_yx_est_vec <- c(pvr_moran_yx_est_vec,pvr_moran_yx_est)
  pvr_moran_yx_p_vec <- c(pvr_moran_yx_p_vec,pvr_moran_yx_p)
  pvr_moran_yx_aic_vec <- c(pvr_moran_yx_aic_vec,pvr_moran_yx_aic)
  pvr_moran_yx_rsq_vec <- c(pvr_moran_yx_rsq_vec,pvr_moran_yx_rsq)
  pvr_moran_yx_npar_vec <- c(pvr_moran_yx_npar_vec,pvr_moran_yx_npar)
  pvr_moran_yx_EV_vec <- c(pvr_moran_yx_EV_vec,pvr_moran_yx_EV)
  pvr_moran_yx_vif_vec <- c(pvr_moran_yx_vif_vec,pvr_moran_yx_vif)

}


### output dataframe #####

my_results <- data.frame(
  
  pvr_ESRBS_xy_npar <- pvr_ESRBS_xy_npar_vec,
  pvr_ESRBS_xy_est <- pvr_ESRBS_xy_est_vec,
  pvr_ESRBS_xy_p <- pvr_ESRBS_xy_p_vec,
  pvr_ESRBS_xy_aic <- pvr_ESRBS_xy_aic_vec,
  pvr_ESRBS_xy_rsq <- pvr_ESRBS_xy_rsq_vec,
  pvr_ESRBS_xy_EV <- pvr_ESRBS_xy_EV_vec,
  pvr_ESRBS_xy_norm_p_n <- pvr_ESRBS_xy_norm_p_n_vec,
  pvr_ESRBS_xy_vif <- pvr_ESRBS_xy_vif_vec,
  
  
  pvr_ESRBS_yx_npar <- pvr_ESRBS_yx_npar_vec,
  pvr_ESRBS_yx_est <- pvr_ESRBS_yx_est_vec,
  pvr_ESRBS_yx_p <- pvr_ESRBS_yx_p_vec,
  pvr_ESRBS_yx_aic <- pvr_ESRBS_yx_aic_vec,
  pvr_ESRBS_yx_rsq <- pvr_ESRBS_yx_rsq_vec,
  pvr_ESRBS_yx_EV <- pvr_ESRBS_yx_EV_vec,
  pvr_ESRBS_yx_norm_p_n <- pvr_ESRBS_yx_norm_p_n_vec,
  pvr_ESRBS_yx_vif <- pvr_ESRBS_yx_vif_vec,
  
  pvr_stepwise_xy_npar <- pvr_stepwise_xy_npar_vec,
  pvr_stepwise_xy_est <- pvr_stepwise_xy_est_vec,
  pvr_stepwise_xy_p <- pvr_stepwise_xy_p_vec,
  pvr_stepwise_xy_aic <- pvr_stepwise_xy_aic_vec,
  pvr_stepwise_xy_rsq <- pvr_stepwise_xy_rsq_vec,
  pvr_stepwise_xy_EV <- pvr_stepwise_xy_EV_vec,
  pvr_stepwise_xy_vif <- pvr_stepwise_xy_vif_vec,
  
  pvr_stepwise_yx_npar <- pvr_stepwise_yx_npar_vec,
  pvr_stepwise_yx_est <- pvr_stepwise_yx_est_vec,
  pvr_stepwise_yx_p <- pvr_stepwise_yx_p_vec,
  pvr_stepwise_yx_aic <- pvr_stepwise_yx_aic_vec,
  pvr_stepwise_yx_rsq <- pvr_stepwise_yx_rsq_vec,
  pvr_stepwise_yx_EV <- pvr_stepwise_yx_EV_vec,
  pvr_stepwise_yx_vif <- pvr_stepwise_yx_vif_vec,
  
  
  pvr_moran_xy_npar <- pvr_moran_xy_npar_vec,
  pvr_moran_xy_est <- pvr_moran_xy_est_vec,
  pvr_moran_xy_p <- pvr_moran_xy_p_vec,
  pvr_moran_xy_aic <- pvr_moran_xy_aic_vec,
  pvr_moran_xy_rsq <- pvr_moran_xy_rsq_vec,
  pvr_moran_xy_EV <- pvr_moran_xy_EV_vec,
  pvr_moran_xy_vif <- pvr_moran_xy_vif_vec,
  
  
  pvr_moran_yx_npar <- pvr_moran_yx_npar_vec,
  pvr_moran_yx_est <- pvr_moran_yx_est_vec,
  pvr_moran_yx_p <- pvr_moran_yx_p_vec,
  pvr_moran_yx_aic <- pvr_moran_yx_aic_vec,
  pvr_moran_yx_rsq <- pvr_moran_yx_rsq_vec,
  pvr_moran_yx_EV <- pvr_moran_yx_EV_vec,
  pvr_moran_yx_vif <- pvr_moran_yx_vif_vec
  
)


#round_results <- round(my_results,3)
colnames(my_results) <- c( 
                           "pvr_ESRBS_xy_npar",
                           "pvr_ESRBS_xy_est",
                           "pvr_ESRBS_xy_p",
                           "pvr_ESRBS_xy_aic",
                           "pvr_ESRBS_xy_rsq",
                           "pvr_ESRBS_xy_EV",
                           "pvr_ESRBS_xy_norm_p_n",
                           "pvr_ESRBS_xy_vif",
                           
                           "pvr_ESRBS_yx_npar",
                           "pvr_ESRBS_yx_est",
                           "pvr_ESRBS_yx_p",
                           "pvr_ESRBS_yx_aic",
                           "pvr_ESRBS_yx_rsq",
                           "pvr_ESRBS_yx_EV",
                           "pvr_ESRBS_yx_norm_p_n",
                           "pvr_ESRBS_yx_vif",
                           
                           "pvr_stepwise_xy_npar",
                           "pvr_stepwise_xy_est",
                           "pvr_stepwise_xy_p",
                           "pvr_stepwise_xy_aic",
                           "pvr_stepwise_xy_rsq",
                           "pvr_stepwise_xy_EV",
                           "pvr_stepwise_xy_vif",
                           
                           
                           "pvr_stepwise_yx_npar",
                           "pvr_stepwise_yx_est",
                           "pvr_stepwise_yx_p",
                           "pvr_stepwise_yx_aic",
                           "pvr_stepwise_yx_rsq",
                           "pvr_stepwise_yx_EV",
                           "pvr_stepwise_yx_vif",
                           
                           "pvr_moran_xy_npar",
                           "pvr_moran_xy_est",
                           "pvr_moran_xy_p",
                           "pvr_moran_xy_aic",
                           "pvr_moran_xy_rsq",
                           "pvr_moran_xy_EV",
                           "pvr_moran_xy_vif",
                           
                           "pvr_moran_yx_npar",
                           "pvr_moran_yx_est",
                           "pvr_moran_yx_p",
                           "pvr_moran_yx_aic",
                           "pvr_moran_yx_rsq",
                           "pvr_moran_yx_EV",
                           "pvr_moran_yx_vif"

)
#round_results$sig_label <- sig_label_vec

out_file <- paste0("results01/",args,"_results.csv")
write.csv(my_results,out_file)

#### END ####
