command <- paste0("ls data1 | wc -l")
system(command)
args <- commandArgs(trailingOnly = TRUE)
library(ape)
library(car)
library(PVR)
library(MASS)

index_num <- 8

my_moran <- function(x, phy=my_tree, trait=NULL, sig = TRUE, sig.t = 0.05, MI.t = 0.05){
  pvr <- x@Eigen$vectors
  model_pre_eigenvectors <- NULL
  tmpTrait <- trait
  model_eigenvectors <- NULL
  model_EV <- NULL
  W <- 1/cophenetic(my_tree)
  diag(W) <- 0
  
  ORIRes <- Moran.I(trait, weight = W, alternative = "two.sided")
  ORIRes_p <- round(ORIRes$p.value, 5)
  ORIRes_I <- ORIRes$observed
  if (ORIRes_p > 0.05 | (ORIRes_p < 0.05 & ORIRes_I < 0)){
    return(model_EV)
  }else{
    for (k in 1:(ncol(pvr)-1)){
      all_EV <- colnames(pvr)
      tmpRes <- matrix(nrow = length(all_EV), ncol = 2) 
      
      for (i in 1:length(all_EV)){
        new_eigenvector <- pvr[,all_EV[i]]
        
        if (is.null(model_pre_eigenvectors)) {
          model_eigenvectors <- new_eigenvector
        } else {
          model_eigenvectors <- cbind(model_pre_eigenvectors, new_eigenvector)
        }
        
        tmpLM <- lm(tmpTrait ~ model_eigenvectors)
        tmpMI <- Moran.I(tmpLM$residuals, weight = W, alternative = "two.sided")
        tmpRes[i, 1] <- round(tmpMI$p.value, 5)
        tmpRes[i, 2] <- tmpMI$observed
      }
      
      idx <- which(tmpRes[,2] == min(tmpRes[,2]))
      
      selected_EV <- all_EV[idx]
      selected_eigenvector <- pvr[,selected_EV]
      all_EV <- all_EV[-idx]
      pvr <- pvr[,!colnames(pvr) %in% selected_EV]
      
      if (is.null(model_pre_eigenvectors)) {
        
        model_pre_eigenvectors <- selected_eigenvector
        model_EV <- selected_EV
      } else {
        model_pre_eigenvectors <- cbind(model_pre_eigenvectors, selected_eigenvector)
        model_EV <- c(model_EV, selected_EV)
      } 
      
      if (tmpRes[idx,1] > 0.05 | (tmpRes[idx,1] < 0.05 & tmpRes[idx,2] < 0)){
        break
      }
      
      k <- k + 1
      
    }
    
    #model_pre_eigenvectors
    return(model_EV)
    
  }
  
}

get_history_change <- function(all_df,relation_df,X){
  L <- length(rownames(relation_df))
  res_vec <- NULL
  for(i in c(1:L)){
    parent <- relation_df$Parent[i]
    child <- relation_df$Child[i]
    parent_trait_X <- all_df[all_df$ID==parent,X]
    child_trait_X <- all_df[all_df$ID==child,X]
    change_X <- (child_trait_X - parent_trait_X)/relation_df$distance[i]
    res_vec <- c(res_vec,change_X)
  }  
  return(res_vec)
}

get_corelated_var <- function(y,pvr_df,my_tree){
  c_num <- length(my_tree$tip.label)-1
  EV_vec <- NULL
  for (c in c(1:c_num)){
    col_name <- paste("c",c,sep="")
    norm_p_y <- shapiro.test(pvr_df[,y])$p.value
    norm_p_EV <- shapiro.test(pvr_df[,col_name])$p.value
    if (norm_p_y>=0.05 & norm_p_EV>=0.05){
      fit <- cor.test(pvr_df[,y],pvr_df[,col_name],method="pearson")
    }else{
      fit <- cor.test(pvr_df[,y],pvr_df[,col_name],method="spearman")
    }
    if (fit$p.value<0.05){
      EV_vec <- c(EV_vec,col_name)
    }
  }
  return(EV_vec)
}

calculate_M_estimator_p <- function(m_model,tips_num){
  t <- summary(m_model)$coefficients[1,3]
  df <- tips_num -2
  p <- 2 * (1-pt(abs(t), df))
  return(p)
}


#### 1. define NULL vector #####
sig_label_vec <- NULL

pvr_ESRBS_est_vec <- NULL
pvr_ESRBS_p_vec <- NULL
pvr_ESRBS_aic_vec <- NULL
pvr_ESRBS_rsq_vec <- NULL
pvr_ESRBS_npar_vec <- NULL
pvr_ESRBS_EV_vec <- NULL
pvr_ESRBS_norm_p_n_vec <- NULL
pvr_ESRBS_vif_vec <- NULL

pvr_stepwise_est_vec <- NULL
pvr_stepwise_p_vec <- NULL
pvr_stepwise_aic_vec <- NULL
pvr_stepwise_rsq_vec <- NULL
pvr_stepwise_npar_vec <- NULL
pvr_stepwise_EV_vec <- NULL
pvr_stepwise_vif_vec <- NULL

pvr_moran_est_vec <- NULL
pvr_moran_p_vec <- NULL
pvr_moran_aic_vec <- NULL
pvr_moran_rsq_vec <- NULL
pvr_moran_npar_vec <- NULL
pvr_moran_EV_vec <- NULL
pvr_moran_vif_vec <- NULL

pearson_est_vec <- NULL
pearson_p_vec <- NULL
spearman_est_vec <- NULL
spearman_p_vec <- NULL



#### 2. batch process ####
for (index in c(1:index_num)){
  sig_label <- "O"
  tips_df_file <- paste0("data1/",index,"/tips_states.csv")
  all_df_file <- paste0("data1/",index,"/all_states.csv")
  relation_file <- paste0("data1/",index,"/Parent2Child.txt")
  my_tree_file <- paste0("data1/",index,"/mytree.nwk")
  relation_df <- read.table(relation_file,sep = " ",header = T)
  all_df <- read.csv(all_df_file)
  tips_df <- read.csv(tips_df_file)
  my_tree <- read.tree(my_tree_file)
  
  tips_num <- length(tips_df$ID)
  relation_df$distance <- my_tree$edge.length
  
  #### 2.4 PVR  ####
  ### decompose the tree to PVRs ##
  x <- PVR::PVRdecomp(my_tree)
  pvrs <- x@Eigen$vectors
  pvr_df <- cbind(tips_df,pvrs)
  
  colnames(pvrs) <- paste0("c",c(1:dim(pvrs)[2]))
  c_num <- length(my_tree$tip.label)-1
  formula_list <- NULL
  
  
  ##### 2.4.1  ESRRV ####
  pvr_name_X1 <- get_corelated_var("X1",pvr_df,my_tree)
  pvr_name_X2 <- get_corelated_var("X2",pvr_df,my_tree)
  
  pvr_union <- union(pvr_name_X1,pvr_name_X2)
  
  pvr_ESRBS_X1_npar <- length(pvr_name_X1)
  pvr_ESRBS_X2_npar <- length(pvr_name_X2)
  pvr_union_npar <- length(pvr_union)
  
  if (pvr_ESRBS_X1_npar==0){
    X1_residual <- pvr_df$X1
  }else{
    X1_pvr_formula <- as.formula(paste0("X1~",pvr_name_X1))
    X1_pvr_ESRBS_lm <- lm(X1_pvr_formula,data=pvr_df)
    X1_residual <- X1_pvr_ESRBS_lm$residuals
  }
  
  if (pvr_ESRBS_X2_npar==0){
    X2_residual <- pvr_df$X2
  }else{
    X2_pvr_formula <- as.formula(paste0("X2~",pvr_name_X2))
    X2_pvr_ESRBS_lm <- lm(X2_pvr_formula,data=pvr_df)
    X2_residual <- X2_pvr_ESRBS_lm$residuals
  }
  
  ESRBS_df <- tips_num - pvr_union_npar -1
  
  ESRBS_r <- cor.test(X1_residual,X2_residual,method = "pearson")$estimate
  
  ESRBS_t <- (ESRBS_r * sqrt(ESRBS_df)) / sqrt(1 - ESRBS_r^2)
  
  # 计算 p 值
  ESRBS_p <- 2 * pt(-abs(ESRBS_t), ESRBS_df)
  
  
  
  ##### 2.4.2  STEPWISE ####
  step_df <- cbind(tips_df,pvrs)
  pvr_step_X1_lm <- lm(X1~.,data = step_df[,c(2,4:(tips_num))])
  pvr_step_X2_lm <- lm(X2~.,data = step_df[,c(3:(tips_num))])
  pvr_X1_STEPWISE <- stepAIC(pvr_step_X1_lm,direction = "both",trace = FALSE)
  pvr_X2_STEPWISE <- stepAIC(pvr_step_X2_lm,direction = "both",trace = FALSE)
  
  pvr_X1_selected_vectors <- colnames(pvr_X1_STEPWISE$qr$qr)[-1]
  pvr_X2_selected_vectors <- colnames(pvr_X2_STEPWISE$qr$qr)[-1]
  
  pvr_stepwise_X1_npar <- length(pvr_X1_selected_vectors)
  pvr_stepwise_X2_npar <- length(pvr_X2_selected_vectors)
  
  pvr_union <- union(pvr_X1_selected_vectors,pvr_X2_selected_vectors)
  
  pvr_union_npar <- length(pvr_union)
  
  if (pvr_stepwise_X1_npar==0){
    X1_residual <- pvr_df$X1
  }else{
    X1_pvr_formula <- as.formula(paste0("X1~",pvr_X1_selected_vectors))
    X1_pvr_stepwise_lm <- lm(X1_pvr_formula,data=pvr_df)
    X1_residual <- X1_pvr_stepwise_lm$residuals
  }
  
  if (pvr_stepwise_X2_npar==0){
    X2_residual <- pvr_df$X2
  }else{
    X2_pvr_formula <- as.formula(paste0("X2~",pvr_X2_selected_vectors))
    X2_pvr_stepwise_lm <- lm(X2_pvr_formula,data=pvr_df)
    X2_residual <- X2_pvr_stepwise_lm$residuals
  }
  
  stepwise_df <- tips_num - pvr_union_npar -1
  
  stepwise_r <- cor.test(X1_residual,X2_residual,method = "pearson")$estimate
  
  stepwise_t <- (stepwise_r * sqrt(stepwise_df)) / sqrt(1 - stepwise_r^2)
  
  # 计算 p 值
  stepwise_p <- 2 * pt(-abs(stepwise_t), stepwise_df)
  
  
  ##### 2.4.3  moran's I ####
  pvr_moran_X1 <- my_moran(x,trait = tips_df[,"X1"],phy = my_tree)
  pvr_moran_X2 <- my_moran(x,trait = tips_df[,"X2"],phy = my_tree)
  
  pvr_moran_X1_npar <- length(pvr_moran_X1)
  pvr_moran_X2_npar <- length(pvr_moran_X2)
  
  pvr_union <- union(pvr_moran_X1,pvr_moran_X2)
  
  pvr_moran_X1_npar <- length(pvr_moran_X1)
  pvr_moran_X2_npar <- length(pvr_moran_X2)
  pvr_union_npar <- length(pvr_union)
  
  if (pvr_moran_X1_npar==0){
    X1_residual <- pvr_df$X1
  }else{
    X1_pvr_formula <- as.formula(paste0("X1~",pvr_moran_X1))
    X1_pvr_moran_lm <- lm(X1_pvr_formula,data=pvr_df)
    X1_residual <- X1_pvr_moran_lm$residuals
  }
  
  if (pvr_moran_X2_npar==0){
    X2_residual <- pvr_df$X2
  }else{
    X2_pvr_formula <- as.formula(paste0("X2~",pvr_moran_X2))
    X2_pvr_moran_lm <- lm(X2_pvr_formula,data=pvr_df)
    X2_residual <- X2_pvr_moran_lm$residuals
  }
  
  moran_df <- tips_num - pvr_union_npar -1
  
  moran_r <- cor.test(X1_residual,X2_residual,method = "pearson")$estimate
  
  moran_t <- (moran_r * sqrt(moran_df)) / sqrt(1 - moran_r^2)
  
  # 计算 p 值
  moran_p <- 2 * pt(-abs(moran_t), moran_df)
  
  #### 2.5 gold standard ####
  ## history PIC ###
  X1_change <- get_history_change(all_df,relation_df,"X1")
  X2_change <- get_history_change(all_df,relation_df,"X2")
  
  spearman_est <- cor.test(X1_change,X2_change,method="spearman")$estimate
  spearman_p <- cor.test(X1_change,X2_change,method="spearman")["p.value"]$p.value
  pearson_est <- cor.test(X1_change,X2_change,method="pearson")$estimate
  pearson_p <- cor.test(X1_change,X2_change,method="pearson")["p.value"]$p.value
  
  #### 3 add results #####
  ##### 3.1 PVR results add. #####
  
  pvr_ESRBS_est_vec <- c(pvr_ESRBS_est_vec,ESRBS_r)
  pvr_ESRBS_p_vec <- c(pvr_ESRBS_p_vec,ESRBS_p)
  
  pvr_stepwise_est_vec <- c(pvr_stepwise_est_vec,stepwise_r)
  pvr_stepwise_p_vec <- c(pvr_stepwise_p_vec,stepwise_p)
  
  pvr_moran_est_vec <- c(pvr_moran_est_vec,moran_r)
  pvr_moran_p_vec <- c(pvr_moran_p_vec,moran_p)
  
  pearson_est_vec <- c(pearson_est_vec,pearson_est)
  pearson_p_vec <- c(pearson_p_vec,pearson_p)
  spearman_est_vec <- c(spearman_est_vec,spearman_est)
  spearman_p_vec <- c(spearman_p_vec,spearman_p)
  
}


### output dataframe #####

my_results <- data.frame(
  ESRBS_est <- pvr_ESRBS_est_vec,
  ESRBS_p <- pvr_ESRBS_p_vec,
  stepwise_est <- pvr_stepwise_est_vec,
  stepwise_p <- pvr_stepwise_p_vec,
  moran_est <- pvr_moran_est_vec,
  moran_p <- pvr_moran_p_vec,
  pearson_est <- pearson_est_vec,
  pearson_p <- pearson_p_vec,
  spearman_est <- spearman_est_vec,
  spearman_p <- spearman_p_vec
  
)


#round_results <- round(my_results,3)
colnames(my_results) <- c( "ESRRV_est","ESRRV_p",
                           "stepwise_est","stepwise_p",
                           "moran_est","moran_p",
                           "pearson_est","pearson_p",
                           "spearman_est","spearman_p"
)
#round_results$sig_label <- sig_label_vec

out_file <- paste0("results1/",args,"_results.csv")
write.csv(my_results,out_file)

#### END ####
