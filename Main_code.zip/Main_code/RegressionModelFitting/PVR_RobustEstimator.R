
system(command)
args <- commandArgs(trailingOnly = TRUE)
library(ape)
library(phytools)
library(phylolm)
library(geiger)
library(ppcor)
library(PVR)
library(L1pack)
library(robust)
library(MASS)

index_num <- 8

my_moran <- function(x, phy=my_tree, trait=NULL, sig = TRUE, sig.t = 0.05, MI.t = 0.05){
  pvr <- x@Eigen$vectors
  model_pre_eigenvectors <- NULL
  tmpTrait <- trait
  model_eigenvectors <- NULL
  model_EV <- NULL
  W <- 1/cophenetic(my_tree)
  diag(W) <- 0
  
  ORIRes <- Moran.I(trait, weight = W, alternative = "two.sided")
  ORIRes_p <- round(ORIRes$p.value, 5)
  ORIRes_I <- ORIRes$observed
  if (ORIRes_p > 0.05 | (ORIRes_p < 0.05 & ORIRes_I < 0)){
    return(model_EV)
  }else{
    for (k in 1:(ncol(pvr)-1)){
      all_EV <- colnames(pvr)
      tmpRes <- matrix(nrow = length(all_EV), ncol = 2) 
      
      for (i in 1:length(all_EV)){
        new_eigenvector <- pvr[,all_EV[i]]
        
        if (is.null(model_pre_eigenvectors)) {
          model_eigenvectors <- new_eigenvector
        } else {
          model_eigenvectors <- cbind(model_pre_eigenvectors, new_eigenvector)
        }
        
        tmpLM <- lm(tmpTrait ~ model_eigenvectors)
        tmpMI <- Moran.I(tmpLM$residuals, weight = W, alternative = "two.sided")
        tmpRes[i, 1] <- round(tmpMI$p.value, 5)
        tmpRes[i, 2] <- tmpMI$observed
      }
      
      idx <- which(tmpRes[,2] == min(tmpRes[,2]))
      
      selected_EV <- all_EV[idx]
      selected_eigenvector <- pvr[,selected_EV]
      all_EV <- all_EV[-idx]
      pvr <- pvr[,!colnames(pvr) %in% selected_EV]
      
      if (is.null(model_pre_eigenvectors)) {
        
        model_pre_eigenvectors <- selected_eigenvector
        model_EV <- selected_EV
      } else {
        model_pre_eigenvectors <- cbind(model_pre_eigenvectors, selected_eigenvector)
        model_EV <- c(model_EV, selected_EV)
      } 
      
      if (tmpRes[idx,1] > 0.05 | (tmpRes[idx,1] < 0.05 & tmpRes[idx,2] < 0)){
        break
      }
      
      k <- k + 1
      
    }
    
    #model_pre_eigenvectors
    return(model_EV)
    
  }
  
}

get_history_change <- function(all_df,relation_df,X){
  L <- length(rownames(relation_df))
  res_vec <- NULL
  for(i in c(1:L)){
    parent <- relation_df$Parent[i]
    child <- relation_df$Child[i]
    parent_trait_X <- all_df[all_df$ID==parent,X]
    child_trait_X <- all_df[all_df$ID==child,X]
    change_X <- (child_trait_X - parent_trait_X)/relation_df$distance[i]
    res_vec <- c(res_vec,change_X)
  }  
  return(res_vec)
}

get_corelated_var <- function(y,pvr_df,my_tree){
  c_num <- length(my_tree$tip.label)-1
  EV_vec <- NULL
  ####### calculate corelate PVRs #########
  for (c in c(1:c_num)){
    col_name <- paste("c",c,sep="")
    norm_p_y <- shapiro.test(pvr_df[,y])$p.value
    norm_p_EV <- shapiro.test(pvr_df[,col_name])$p.value
    if (norm_p_y>=0.05 & norm_p_EV>=0.05){
      fit <- cor.test(pvr_df[,y],pvr_df[,col_name],method="pearson")
    }else{
      fit <- cor.test(pvr_df[,y],pvr_df[,col_name],method="spearman")
    }
    if (fit$p.value<0.05){
      EV_vec <- c(EV_vec,col_name)
    }
  }
  return(EV_vec)
}

calculate_M_estimator_p <- function(t,tips_num){
  df <- tips_num -2
  p <- 2 * (1-pt(abs(t), df))
  return(p)
}

calculate_L1_rsquare <- function(L1model,pvr_df, y){
  y_pred <- predict(L1model)
  TAD <- sum(abs(pvr_df[,y] - mean(pvr_df[,y])))
  RAD <- sum(abs(pvr_df[,y] - y_pred))
  R_squared <- 1 - (RAD / TAD)
  return(R_squared)
}

calculate_S_aic <- function(Smodel,pvr_df){
  rss <- sum(Smodel$residuals^2)
  n <- length(Smodel$residuals)
  k <- length(coef(Smodel))
  AIC <- n *log(rss/n) + 2 * k
  return(AIC)
}

calculate_M_rsquare <- function(Mmodel,pvr_df, y){
  y_pred <- predict(Mmodel)
  TSS <- sum((pvr_df[,y] - mean(pvr_df[,y]))^2)
  RSS <- sum(Mmodel$residuals^2)
  R_squared <- 1 - (RSS / TSS)
  return(R_squared)
}


#### 1. define NULL vector #####
change_est_vec <- NULL
change_p_vec <- NULL
spearman_est_vec <- NULL
spearman_p_vec <- NULL

X1_lambda_vec <- NULL
X1_lambda_p_vec <- NULL
X2_lambda_vec <- NULL
X2_lambda_p_vec <- NULL

X1_K_vec <- NULL
X1_K_p_vec <- NULL
X2_K_vec <- NULL
X2_K_p_vec <- NULL

### 1.1.1 ESRBS-L2 ######
pvr_ESRBS_xy_L2_est_vec <- NULL
pvr_ESRBS_xy_L2_p_vec <- NULL
pvr_ESRBS_xy_L2_aic_vec <- NULL
pvr_ESRBS_xy_L2_rsq_vec <- NULL

### 1.1.2 ESRBS-L1 ######
pvr_ESRBS_xy_L1_est_vec <- NULL
pvr_ESRBS_xy_L1_p_vec <- NULL
pvr_ESRBS_xy_L1_aic_vec <- NULL
pvr_ESRBS_xy_L1_rsq_vec <- NULL

### 1.1.3 ESRBS-S ######
pvr_ESRBS_xy_S_est_vec <- NULL
pvr_ESRBS_xy_S_p_vec <- NULL
pvr_ESRBS_xy_S_aic_vec <- NULL
pvr_ESRBS_xy_S_rsq_vec <- NULL

### 1.1.4 ESRBS-MM ######
pvr_ESRBS_xy_MM_est_vec <- NULL
pvr_ESRBS_xy_MM_p_vec <- NULL
pvr_ESRBS_xy_MM_aic_vec <- NULL
pvr_ESRBS_xy_MM_rsq_vec <- NULL

### 1.1.5 ESRBS-M ######
pvr_ESRBS_xy_M_est_vec <- NULL
pvr_ESRBS_xy_M_p_vec <- NULL
pvr_ESRBS_xy_M_aic_vec <- NULL
pvr_ESRBS_xy_M_rsq_vec <- NULL

### 1.2.1 moran-L2 ######
pvr_moran_xy_L2_est_vec <- NULL
pvr_moran_xy_L2_p_vec <- NULL
pvr_moran_xy_L2_aic_vec <- NULL
pvr_moran_xy_L2_rsq_vec <- NULL

### 1.2.2 moran-L1 ######
pvr_moran_xy_L1_est_vec <- NULL
pvr_moran_xy_L1_p_vec <- NULL
pvr_moran_xy_L1_aic_vec <- NULL
pvr_moran_xy_L1_rsq_vec <- NULL

### 1.2.3 moran-S ######
pvr_moran_xy_S_est_vec <- NULL
pvr_moran_xy_S_p_vec <- NULL
pvr_moran_xy_S_aic_vec <- NULL
pvr_moran_xy_S_rsq_vec <- NULL

### 1.2.4 moran-MM ######
pvr_moran_xy_MM_est_vec <- NULL
pvr_moran_xy_MM_p_vec <- NULL
pvr_moran_xy_MM_aic_vec <- NULL
pvr_moran_xy_MM_rsq_vec <- NULL

### 1.2.5 moran-M ######
pvr_moran_xy_M_est_vec <- NULL
pvr_moran_xy_M_p_vec <- NULL
pvr_moran_xy_M_aic_vec <- NULL
pvr_moran_xy_M_rsq_vec <- NULL




#index<-1
#### 2. batch process ####
for (index in c(1:index_num)){
  sig_label <- "O"
  tips_df_file <- paste0("data3/",index,"/tips_states.csv")
  all_df_file <- paste0("data3/",index,"/all_states.csv")
  relation_file <- paste0("data3/",index,"/Parent2Child.txt")
  my_tree_file <- paste0("data3/",index,"/mytree.nwk")
  relation_df <- read.table(relation_file,sep = " ",header = T)
  all_df <- read.csv(all_df_file)
  tips_df <- read.csv(tips_df_file)
  my_tree <- read.tree(my_tree_file)
  
  tips_num <- length(tips_df$ID)
  relation_df$distance <- my_tree$edge.length
  #### 2.1 PVR  ####
  ### decompose the tree to PVRs ##
  x <- PVR::PVRdecomp(my_tree)
  pvrs <- x@Eigen$vectors
  pvr_df <- cbind(tips_df,pvrs)
  
  colnames(pvrs) <- paste0("c",c(1:dim(pvrs)[2]))
  c_num <- length(my_tree$tip.label)-1
  formula_list <- NULL
  
  
  ##### 2.1.1  ESRRV ####
  pvr_name_X1 <- get_corelated_var("X1",pvr_df,my_tree)
  pvr_name_X2 <- get_corelated_var("X2",pvr_df,my_tree)
  
  pvr_ESRBS_xy <- union(pvr_name_X1,pvr_name_X2)
  pvr_ESRBS_xy_npar <- length(pvr_ESRBS_xy)
  if (pvr_ESRBS_xy_npar==0){
    xy_pvr_formula <- as.formula(paste0("X1~X2"))
    pvr_ESRBS_xy_EV <- c("0")
    
  }else{
    consider_xy_pvr <- paste(sort(pvr_ESRBS_xy),collapse="+")
    xy_pvr_formula <- as.formula(paste0("X1~X2+",consider_xy_pvr))
    pvr_ESRBS_xy_EV <- consider_xy_pvr
    
  }
  #### 2.1.1.1 L2-estimator ######
  pvr_ESRBS_xy_L2_lm <- lm(xy_pvr_formula,data=pvr_df)
  #### 2.1.1.2 L1-estimator ######
  pvr_ESRBS_xy_L1_lm <- lad(xy_pvr_formula,data=pvr_df, method = "EM")
  #### 2.1.1.3 S-estimator ######
  if (pvr_ESRBS_xy_npar > 10){
    pvr_all_vec <- strsplit(as.character(xy_pvr_formula)[3],split="+",fixed="T")[[1]][-1]
    num_part <- as.numeric(gsub("c", "", pvr_all_vec))
    sorted_vec <- pvr_all_vec[order(num_part)]
    xy_pvr_formula_lmRob_right <- paste(c("X2",sorted_vec[1:10]),collapse = "+")
    xy_pvr_formula_lmRob_left <- as.character(xy_pvr_formula)[2]
    xy_pvr_formula_lmRob <- as.formula(paste0(xy_pvr_formula_lmRob_left,"~",xy_pvr_formula_lmRob_right)) 
  }else{
    xy_pvr_formula_lmRob <- xy_pvr_formula
  }
  pvr_ESRBS_xy_S_lm <- lmRob(xy_pvr_formula_lmRob,data=pvr_df,estim="Initial")
  #### 2.1.1.4 MM-estimator ######
  if (pvr_ESRBS_xy_npar > 10){
    pvr_all_vec <- strsplit(as.character(xy_pvr_formula)[3],split="+",fixed="T")[[1]][-1]
    num_part <- as.numeric(gsub("c", "", pvr_all_vec))
    sorted_vec <- pvr_all_vec[order(num_part)]
    xy_pvr_formula_lmRob_right <- paste(c("X2",sorted_vec[1:10]),collapse = "+")
    xy_pvr_formula_lmRob_left <- as.character(xy_pvr_formula)[2]
    xy_pvr_formula_lmRob <- as.formula(paste0(xy_pvr_formula_lmRob_left,"~",xy_pvr_formula_lmRob_right)) 
  }else{
    xy_pvr_formula_lmRob <- xy_pvr_formula
  }
  pvr_ESRBS_xy_MM_lm <- lmRob(xy_pvr_formula_lmRob,data=pvr_df)
  #### 2.1.1.5 M-estimator ######
  pvr_ESRBS_xy_M_lm <- rlm(as.formula(xy_pvr_formula), data=pvr_df, method = "M", scale.est = "Huber", k2 = 1.345)
  
  pvr_ESRBS_xy_L2_est <- summary(pvr_ESRBS_xy_L2_lm)$coefficients[2,1]
  pvr_ESRBS_xy_L2_p <- summary(pvr_ESRBS_xy_L2_lm)$coefficients[2,4]
  pvr_ESRBS_xy_L2_aic <- AIC(pvr_ESRBS_xy_L2_lm,k=pvr_ESRBS_xy_npar)
  pvr_ESRBS_xy_L2_rsq <- summary(pvr_ESRBS_xy_L2_lm)$r.squared
  
  pvr_ESRBS_xy_L1_est <- summary(pvr_ESRBS_xy_L1_lm)$coefficients[2,1]
  pvr_ESRBS_xy_L1_p <- summary(pvr_ESRBS_xy_L1_lm)$coefficients[2,4]
  pvr_ESRBS_xy_L1_aic <- AIC(pvr_ESRBS_xy_L1_lm,k=pvr_ESRBS_xy_npar)
  pvr_ESRBS_xy_L1_rsq <- calculate_L1_rsquare(pvr_ESRBS_xy_L1_lm,pvr_df,"X1")
  
  pvr_ESRBS_xy_S_est <- summary(pvr_ESRBS_xy_S_lm)$coefficients[2,1]
  pvr_ESRBS_xy_S_p <- summary(pvr_ESRBS_xy_S_lm)$coefficients[2,4]
  pvr_ESRBS_xy_S_aic <- calculate_S_aic(pvr_ESRBS_xy_S_lm,pvr_df)
  pvr_ESRBS_xy_S_rsq <- summary(pvr_ESRBS_xy_S_lm)$r.square
  
  pvr_ESRBS_xy_MM_est <- summary(pvr_ESRBS_xy_MM_lm)$coefficients[2,1]
  pvr_ESRBS_xy_MM_p <- summary(pvr_ESRBS_xy_MM_lm)$coefficients[2,4]
  pvr_ESRBS_xy_MM_aic <- calculate_S_aic(pvr_ESRBS_xy_MM_lm,pvr_df)
  pvr_ESRBS_xy_MM_rsq <- summary(pvr_ESRBS_xy_MM_lm)$r.square
  
  pvr_ESRBS_xy_M_est <- summary(pvr_ESRBS_xy_M_lm)$coefficients[2,1]
  pvr_ESRBS_xy_M_t <- summary(pvr_ESRBS_xy_M_lm)$coefficients[2,3]
  pvr_ESRBS_xy_M_aic <- AIC(pvr_ESRBS_xy_M_lm,k=pvr_ESRBS_xy_npar)
  pvr_ESRBS_xy_M_p <- calculate_M_estimator_p(pvr_ESRBS_xy_M_t,tips_num)
  pvr_ESRBS_xy_M_rsq <- calculate_M_rsquare(pvr_ESRBS_xy_M_lm,pvr_df, "X1")
  
  
  ##### 2.1.2  moran's I ####
  pvr_name_X1 <- my_moran(x,trait = tips_df[,"X1"],phy = my_tree)
  pvr_name_X2 <- my_moran(x,trait = tips_df[,"X2"],phy = my_tree)
  
  pvr_moran_xy <- union(pvr_name_X1,pvr_name_X2)
  pvr_moran_xy_npar <- length(pvr_moran_xy)
  
  if (pvr_moran_xy_npar==0){
    xy_pvr_formula <- as.formula(paste0("X1~X2"))
    pvr_moran_xy_EV <- c("0")
  }else{
    consider_xy_pvr <- paste(sort(pvr_moran_xy),collapse="+")
    xy_pvr_formula <- as.formula(paste0("X1~X2+",consider_xy_pvr))
    pvr_moran_xy_EV <- consider_xy_pvr
  }
  
  #### 2.1.1.1 L2-estimator ######
  pvr_moran_xy_L2_lm <- lm(xy_pvr_formula,data=pvr_df)
  #### 2.1.1.2 L1-estimator ######
  pvr_moran_xy_L1_lm <- lad(xy_pvr_formula,data=pvr_df, method = "EM")
  #### 2.1.1.3 S-estimator ######
  if (pvr_moran_xy_npar > 10){
    pvr_all_vec <- strsplit(as.character(xy_pvr_formula)[3],split="+",fixed="T")[[1]][-1]
    num_part <- as.numeric(gsub("c", "", pvr_all_vec))
    sorted_vec <- pvr_all_vec[order(num_part)]
    xy_pvr_formula_lmRob_right <- paste(c("X2",sorted_vec[1:10]),collapse = "+")
    xy_pvr_formula_lmRob_left <- as.character(xy_pvr_formula)[2]
    xy_pvr_formula_lmRob <- as.formula(paste0(xy_pvr_formula_lmRob_left,"~",xy_pvr_formula_lmRob_right)) 
  }else{
    xy_pvr_formula_lmRob <- xy_pvr_formula
  }
  pvr_moran_xy_S_lm <- lmRob(xy_pvr_formula_lmRob,data=pvr_df,estim="Initial")
  #### 2.1.1.4 MM-estimator ######
  if (pvr_moran_xy_npar > 10){
    pvr_all_vec <- strsplit(as.character(xy_pvr_formula)[3],split="+",fixed="T")[[1]][-1]
    num_part <- as.numeric(gsub("c", "", pvr_all_vec))
    sorted_vec <- pvr_all_vec[order(num_part)]
    xy_pvr_formula_lmRob_right <- paste(c("X2",sorted_vec[1:10]),collapse = "+")
    xy_pvr_formula_lmRob_left <- as.character(xy_pvr_formula)[2]
    xy_pvr_formula_lmRob <- as.formula(paste0(xy_pvr_formula_lmRob_left,"~",xy_pvr_formula_lmRob_right)) 
  }else{
    xy_pvr_formula_lmRob <- xy_pvr_formula
  }
  pvr_moran_xy_MM_lm <- lmRob(xy_pvr_formula_lmRob,data=pvr_df)
  #### 2.1.1.5 M-estimator ######
  pvr_moran_xy_M_lm <- rlm(as.formula(xy_pvr_formula), data=pvr_df, method = "M", scale.est = "Huber", k2 = 1.345)
  
  pvr_moran_xy_L2_est <- summary(pvr_moran_xy_L2_lm)$coefficients[2,1]
  pvr_moran_xy_L2_p <- summary(pvr_moran_xy_L2_lm)$coefficients[2,4]
  pvr_moran_xy_L2_aic <- AIC(pvr_moran_xy_L2_lm,k=pvr_moran_xy_npar)
  pvr_moran_xy_L2_rsq <- summary(pvr_moran_xy_L2_lm)$r.squared
  
  pvr_moran_xy_L1_est <- summary(pvr_moran_xy_L1_lm)$coefficients[2,1]
  pvr_moran_xy_L1_p <- summary(pvr_moran_xy_L1_lm)$coefficients[2,4]
  pvr_moran_xy_L1_aic <- AIC(pvr_moran_xy_L1_lm,k=pvr_moran_xy_npar)
  pvr_moran_xy_L1_rsq <- calculate_L1_rsquare(pvr_moran_xy_L1_lm,pvr_df,"X1")
  
  pvr_moran_xy_S_est <- summary(pvr_moran_xy_S_lm)$coefficients[2,1]
  pvr_moran_xy_S_p <- summary(pvr_moran_xy_S_lm)$coefficients[2,4]
  pvr_moran_xy_S_aic <- calculate_S_aic(pvr_moran_xy_S_lm,pvr_df)
  pvr_moran_xy_S_rsq <- summary(pvr_moran_xy_S_lm)$r.square
  
  pvr_moran_xy_MM_est <- summary(pvr_moran_xy_MM_lm)$coefficients[2,1]
  pvr_moran_xy_MM_p <- summary(pvr_moran_xy_MM_lm)$coefficients[2,4]
  pvr_moran_xy_MM_aic <- calculate_S_aic(pvr_moran_xy_MM_lm,pvr_df)
  pvr_moran_xy_MM_rsq <- summary(pvr_moran_xy_MM_lm)$r.square
  
  pvr_moran_xy_M_est <- summary(pvr_moran_xy_M_lm)$coefficients[2,1]
  pvr_moran_xy_M_t <- summary(pvr_moran_xy_M_lm)$coefficients[2,3]
  pvr_moran_xy_M_aic <- AIC(pvr_moran_xy_M_lm,k=pvr_moran_xy_npar)
  pvr_moran_xy_M_p <- calculate_M_estimator_p(pvr_moran_xy_M_t,tips_num)
  pvr_moran_xy_M_rsq <- calculate_M_rsquare(pvr_moran_xy_M_lm,pvr_df, "X1")
  
  #### 2.2 gold standard ####
  ## history PIC ###
  X1_change <- get_history_change(all_df,relation_df,"X1")
  X2_change <- get_history_change(all_df,relation_df,"X2")
  
  ##### 2.2.1 original_data ####
  change_formula <- as.formula(paste0("X1_change~X2_change"))
  change_est <- summary(lm(change_formula))$coefficients[2,1]
  change_p <- summary(lm(change_formula))$coefficients[2,4]
  spearman_est <- cor.test(X1_change,X2_change,method="spearman")$estimate
  spearman_p <- cor.test(X1_change,X2_change,method="spearman")["p.value"]$p.value

  #### 2.3 signal part####
  X1_vec <- tips_df$X1
  X2_vec <- tips_df$X2
  names(X1_vec) <- tips_df$ID
  names(X2_vec) <- tips_df$ID
  X1.lambda <- phylosig(my_tree,X1_vec,method = "lambda",test=T)
  X1.K <- phylosig(my_tree,X1_vec,method = "K",test=T)
  X2.lambda <- phylosig(my_tree,X2_vec,method = "lambda",test=T)
  X2.K <- phylosig(my_tree,X2_vec,method = "K",test=T)
  
  X1_lambda <- X1.lambda$lambda
  X1_lambda_p <- X1.lambda$P
  X1_K <- X1.K$K
  X1_K_p <- X1.K$P
  
  X2_lambda <- X2.lambda$lambda
  X2_lambda_p <- X2.lambda$P
  X2_K <- X2.K$K
  X2_K_p <- X2.K$P

  #### 2.4 add results #####

  ##### 2.4.1 PVR results add. #####
  
  ### 5.1.1 ESRRV add ####
  pvr_ESRBS_xy_L2_est_vec <- c(pvr_ESRBS_xy_L2_est_vec,pvr_ESRBS_xy_L2_est)
  pvr_ESRBS_xy_L2_p_vec <- c(pvr_ESRBS_xy_L2_p_vec,pvr_ESRBS_xy_L2_p)
  pvr_ESRBS_xy_L2_aic_vec <- c(pvr_ESRBS_xy_L2_aic_vec,pvr_ESRBS_xy_L2_aic)
  pvr_ESRBS_xy_L2_rsq_vec <- c(pvr_ESRBS_xy_L2_rsq_vec,pvr_ESRBS_xy_L2_rsq)

  pvr_ESRBS_xy_L1_est_vec <- c(pvr_ESRBS_xy_L1_est_vec,pvr_ESRBS_xy_L1_est)
  pvr_ESRBS_xy_L1_p_vec <- c(pvr_ESRBS_xy_L1_p_vec,pvr_ESRBS_xy_L1_p)
  pvr_ESRBS_xy_L1_aic_vec <- c(pvr_ESRBS_xy_L1_aic_vec,pvr_ESRBS_xy_L1_aic)
  pvr_ESRBS_xy_L1_rsq_vec <- c(pvr_ESRBS_xy_L1_rsq_vec,pvr_ESRBS_xy_L1_rsq)

  pvr_ESRBS_xy_S_est_vec <- c(pvr_ESRBS_xy_S_est_vec,pvr_ESRBS_xy_S_est)
  pvr_ESRBS_xy_S_p_vec <- c(pvr_ESRBS_xy_S_p_vec,pvr_ESRBS_xy_S_p)
  pvr_ESRBS_xy_S_aic_vec <- c(pvr_ESRBS_xy_S_aic_vec,pvr_ESRBS_xy_S_aic)
  pvr_ESRBS_xy_S_rsq_vec <- c(pvr_ESRBS_xy_S_rsq_vec,pvr_ESRBS_xy_S_rsq)

  pvr_ESRBS_xy_M_est_vec <- c(pvr_ESRBS_xy_M_est_vec,pvr_ESRBS_xy_M_est)
  pvr_ESRBS_xy_M_p_vec <- c(pvr_ESRBS_xy_M_p_vec,pvr_ESRBS_xy_M_p)
  pvr_ESRBS_xy_M_aic_vec <- c(pvr_ESRBS_xy_M_aic_vec,pvr_ESRBS_xy_M_aic)
  pvr_ESRBS_xy_M_rsq_vec <- c(pvr_ESRBS_xy_M_rsq_vec,pvr_ESRBS_xy_M_rsq)

  pvr_ESRBS_xy_MM_est_vec <- c(pvr_ESRBS_xy_MM_est_vec,pvr_ESRBS_xy_MM_est)
  pvr_ESRBS_xy_MM_p_vec <- c(pvr_ESRBS_xy_MM_p_vec,pvr_ESRBS_xy_MM_p)
  pvr_ESRBS_xy_MM_aic_vec <- c(pvr_ESRBS_xy_MM_aic_vec,pvr_ESRBS_xy_MM_aic)
  pvr_ESRBS_xy_MM_rsq_vec <- c(pvr_ESRBS_xy_MM_rsq_vec,pvr_ESRBS_xy_MM_rsq)
  
  
  ## moran's I add ##
  pvr_moran_xy_L2_est_vec <- c(pvr_moran_xy_L2_est_vec,pvr_moran_xy_L2_est)
  pvr_moran_xy_L2_p_vec <- c(pvr_moran_xy_L2_p_vec,pvr_moran_xy_L2_p)
  pvr_moran_xy_L2_aic_vec <- c(pvr_moran_xy_L2_aic_vec,pvr_moran_xy_L2_aic)
  pvr_moran_xy_L2_rsq_vec <- c(pvr_moran_xy_L2_rsq_vec,pvr_moran_xy_L2_rsq)
  
  pvr_moran_xy_L1_est_vec <- c(pvr_moran_xy_L1_est_vec,pvr_moran_xy_L1_est)
  pvr_moran_xy_L1_p_vec <- c(pvr_moran_xy_L1_p_vec,pvr_moran_xy_L1_p)
  pvr_moran_xy_L1_aic_vec <- c(pvr_moran_xy_L1_aic_vec,pvr_moran_xy_L1_aic)
  pvr_moran_xy_L1_rsq_vec <- c(pvr_moran_xy_L1_rsq_vec,pvr_moran_xy_L1_rsq)
  
  pvr_moran_xy_S_est_vec <- c(pvr_moran_xy_S_est_vec,pvr_moran_xy_S_est)
  pvr_moran_xy_S_p_vec <- c(pvr_moran_xy_S_p_vec,pvr_moran_xy_S_p)
  pvr_moran_xy_S_aic_vec <- c(pvr_moran_xy_S_aic_vec,pvr_moran_xy_S_aic)
  pvr_moran_xy_S_rsq_vec <- c(pvr_moran_xy_S_rsq_vec,pvr_moran_xy_S_rsq)
  
  pvr_moran_xy_M_est_vec <- c(pvr_moran_xy_M_est_vec,pvr_moran_xy_M_est)
  pvr_moran_xy_M_p_vec <- c(pvr_moran_xy_M_p_vec,pvr_moran_xy_M_p)
  pvr_moran_xy_M_aic_vec <- c(pvr_moran_xy_M_aic_vec,pvr_moran_xy_M_aic)
  pvr_moran_xy_M_rsq_vec <- c(pvr_moran_xy_M_rsq_vec,pvr_moran_xy_M_rsq)
  
  pvr_moran_xy_MM_est_vec <- c(pvr_moran_xy_MM_est_vec,pvr_moran_xy_MM_est)
  pvr_moran_xy_MM_p_vec <- c(pvr_moran_xy_MM_p_vec,pvr_moran_xy_MM_p)
  pvr_moran_xy_MM_aic_vec <- c(pvr_moran_xy_MM_aic_vec,pvr_moran_xy_MM_aic)
  pvr_moran_xy_MM_rsq_vec <- c(pvr_moran_xy_MM_rsq_vec,pvr_moran_xy_MM_rsq)
  
  ##### 2.4.2 Gold standard add #### 
  change_est_vec <- c(change_est_vec,change_est)
  change_p_vec <- c(change_p_vec,change_p)
  spearman_est_vec <- c(spearman_est_vec,spearman_est)
  spearman_p_vec <- c(spearman_p_vec,spearman_p)
  
  ##### 2.4.3 Signal add ####
  X1_lambda_vec <- c(X1_lambda_vec,X1_lambda)
  X1_lambda_p_vec <- c(X1_lambda_p_vec,X1_lambda_p)
  X2_lambda_vec <- c(X2_lambda_vec,X2_lambda)
  X2_lambda_p_vec <- c(X2_lambda_p_vec,X2_lambda_p)
  X1_K_vec <- c(X1_K_vec,X1_K)
  X1_K_p_vec <- c(X1_K_p_vec,X1_K_p)
  X2_K_vec <- c(X2_K_vec,X2_K)
  X2_K_p_vec <- c(X2_K_p_vec,X2_K_p)
}


### output dataframe #####

my_results <- data.frame(
  "X1_lambda" <- X1_lambda_vec,
  "X1_lambda_p" <- X1_lambda_p_vec,
  "X2_lambda" <- X2_lambda_vec,
  "X2_lambda_p" <- X2_lambda_p_vec,
  "X1_K" <- X1_K_vec,
  "X1_K_p" <- X1_K_p_vec,
  "X2_K" <- X2_K_vec,
  "X2_K_p" <- X2_K_p_vec,
  
  "pvr_ESRBS_xy_L2_est" <- pvr_ESRBS_xy_L2_est_vec,
  "pvr_ESRBS_xy_L2_p" <- pvr_ESRBS_xy_L2_p_vec,
  "pvr_ESRBS_xy_L2_aic" <- pvr_ESRBS_xy_L2_aic_vec,
  "pvr_ESRBS_xy_L2_rsq" <- pvr_ESRBS_xy_L2_rsq_vec,

  "pvr_ESRBS_xy_L1_est" <- pvr_ESRBS_xy_L1_est_vec,
  "pvr_ESRBS_xy_L1_p" <- pvr_ESRBS_xy_L1_p_vec,
  "pvr_ESRBS_xy_L1_aic" <- pvr_ESRBS_xy_L1_aic_vec,
  "pvr_ESRBS_xy_L1_rsq" <- pvr_ESRBS_xy_L1_rsq_vec,

  "pvr_ESRBS_xy_S_est" <- pvr_ESRBS_xy_S_est_vec,
  "pvr_ESRBS_xy_S_p" <- pvr_ESRBS_xy_S_p_vec,
  "pvr_ESRBS_xy_S_aic" <- pvr_ESRBS_xy_S_aic_vec,
  "pvr_ESRBS_xy_S_rsq" <- pvr_ESRBS_xy_S_rsq_vec,
  
  "pvr_ESRBS_xy_MM_est" <- pvr_ESRBS_xy_MM_est_vec,
  "pvr_ESRBS_xy_MM_p" <- pvr_ESRBS_xy_MM_p_vec,
  "pvr_ESRBS_xy_MM_aic" <- pvr_ESRBS_xy_MM_aic_vec,
  "pvr_ESRBS_xy_MM_rsq" <- pvr_ESRBS_xy_MM_rsq_vec,
  
  "pvr_ESRBS_xy_M_est" <- pvr_ESRBS_xy_M_est_vec,
  "pvr_ESRBS_xy_M_p" <- pvr_ESRBS_xy_M_p_vec,
  "pvr_ESRBS_xy_M_aic" <- pvr_ESRBS_xy_M_aic_vec,
  "pvr_ESRBS_xy_M_rsq" <- pvr_ESRBS_xy_M_rsq_vec,

  "pvr_moran_xy_L2_est" <- pvr_moran_xy_L2_est_vec,
  "pvr_moran_xy_L2_p" <- pvr_moran_xy_L2_p_vec,
  "pvr_moran_xy_L2_aic" <- pvr_moran_xy_L2_aic_vec,
  "pvr_moran_xy_L2_rsq" <- pvr_moran_xy_L2_rsq_vec,
  
  "pvr_moran_xy_L1_est" <- pvr_moran_xy_L1_est_vec,
  "pvr_moran_xy_L1_p" <- pvr_moran_xy_L1_p_vec,
  "pvr_moran_xy_L1_aic" <- pvr_moran_xy_L1_aic_vec,
  "pvr_moran_xy_L1_rsq" <- pvr_moran_xy_L1_rsq_vec,

  "pvr_moran_xy_S_est" <- pvr_moran_xy_S_est_vec,
  "pvr_moran_xy_S_p" <- pvr_moran_xy_S_p_vec,
  "pvr_moran_xy_S_aic" <- pvr_moran_xy_S_aic_vec,
  "pvr_moran_xy_S_rsq" <- pvr_moran_xy_S_rsq_vec,

  "pvr_moran_xy_MM_est" <- pvr_moran_xy_MM_est_vec,
  "pvr_moran_xy_MM_p" <- pvr_moran_xy_MM_p_vec,
  "pvr_moran_xy_MM_aic" <- pvr_moran_xy_MM_aic_vec,
  "pvr_moran_xy_MM_rsq" <- pvr_moran_xy_MM_rsq_vec,

  "pvr_moran_xy_M_est" <- pvr_moran_xy_M_est_vec,
  "pvr_moran_xy_M_p" <- pvr_moran_xy_M_p_vec,
  "pvr_moran_xy_M_aic" <- pvr_moran_xy_M_aic_vec,
  "pvr_moran_xy_M_rsq" <- pvr_moran_xy_M_rsq_vec,
  
  "change_est" <- change_est_vec,
  "change_p" <- change_p_vec,
  "spearman_est" <- spearman_est_vec,
  "spearman_p" <- spearman_p_vec
)



#round_results <- round(my_results,3)
colnames(my_results) <- c(  "X1_lambda",
                            "X1_lambda_p",
                            "X2_lambda",
                            "X2_lambda_p",
                            "X1_K",
                            "X1_K_p",
                            "X2_K",
                            "X2_K_p",
                   
                            "pvr_ESRBS_xy_L2_est",
                            "pvr_ESRBS_xy_L2_p",
                            "pvr_ESRBS_xy_L2_aic",
                            "pvr_ESRBS_xy_L2_rsq",
                     
                            "pvr_ESRBS_xy_L1_est",
                            "pvr_ESRBS_xy_L1_p",
                            "pvr_ESRBS_xy_L1_aic",
                            "pvr_ESRBS_xy_L1_rsq",
                            
                            "pvr_ESRBS_xy_S_est",
                            "pvr_ESRBS_xy_S_p",
                            "pvr_ESRBS_xy_S_aic",
                            "pvr_ESRBS_xy_S_rsq",
                            
                            "pvr_ESRBS_xy_MM_est",
                            "pvr_ESRBS_xy_MM_p",
                            "pvr_ESRBS_xy_MM_aic",
                            "pvr_ESRBS_xy_MM_rsq",
                            
                            "pvr_ESRBS_xy_M_est",
                            "pvr_ESRBS_xy_M_p",
                            "pvr_ESRBS_xy_M_aic",
                            "pvr_ESRBS_xy_M_rsq",
                            
                            "pvr_moran_xy_L2_est",
                            "pvr_moran_xy_L2_p",
                            "pvr_moran_xy_L2_aic",
                            "pvr_moran_xy_L2_rsq",
           
                            "pvr_moran_xy_L1_est",
                            "pvr_moran_xy_L1_p",
                            "pvr_moran_xy_L1_aic",
                            "pvr_moran_xy_L1_rsq",

                            "pvr_moran_xy_S_est",
                            "pvr_moran_xy_S_p",
                            "pvr_moran_xy_S_aic",
                            "pvr_moran_xy_S_rsq",

                            "pvr_moran_xy_MM_est",
                            "pvr_moran_xy_MM_p",
                            "pvr_moran_xy_MM_aic",
                            "pvr_moran_xy_MM_rsq",

                            "pvr_moran_xy_M_est",
                            "pvr_moran_xy_M_p",
                            "pvr_moran_xy_M_aic",
                            "pvr_moran_xy_M_rsq",
                            
                            "change_est",
                            "change_p",
                            "spearman_est",
                            "spearman_p"

)
#round_results$sig_label <- sig_label_vec

out_file <- paste0("results3/",args,"_results.csv")
write.csv(my_results,out_file)

####### END ######
