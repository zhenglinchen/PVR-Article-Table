There are foursubdirectories in the **Main_code** directory,  **TreeConstruction** , **TraitsSimulation**, **RegressionModelFitting** and **StatisticalAnalysis**.

**TreeConstruction** contains five scripts:

1. **128balanced_rho_1.R** is used to construct a balanced tree with Grafen's rho = 1, (128 species).

2.  **128balanced_rho_01.R** is used to construct a balanced tree with Grafen's rho = 0.1, (128 species).

3.  **128balanced_rho_2.R** is used to construct a balanced tree with Grafen's rho = 2, (128 species).

4.  **128ladder_rho_1.R** is used to construct a ladder-like tree with Grafen's rho = 1, (128 species).

5. **16balanced_rho_1.R** is used to construct a balanced tree with Grafen's rho = 1, (16 species).

   

**TraitsSimulation** contains six scripts, each corresponds to the traits simulation scenario.



The scripts in the **RegressionModelFitting** directory are used for regression model fit:

1. PGLS_RobustEstimator.R is for PGLS, PIC and PIC-MM
2. PVR_ResidualAnalysis.R is for correlation test of residual of X1 and X2 when controling phylogenetic autocorrelation seperately.
3. PVR_RobustEstimator.R is for PVR_union with various estimators
4. PVR_SingleEV.R is for the original PVR considering the eigenvector of single variable(X1 or X2).  



The scripts in the **StatisticalAnalysis** directory are used for regression model fit:

1. **Table01_EV_XYYXUnion.R** is used to count the number of selected eigenvectors 

2. **Table01_EVDiff.R** is used to count the number of divergent eigenvector sets

3. **Table02_conflictingnumber_kappa** is used to test the divergent correlation results

4. **Table03_Cor_diff.R** is used to get the differences of correlation coefficients

5. **Table05_Residual_Pearson** is used to get the results of Residual analysis

6. Table06_PGLS_best.R is used to get the best PGLS results

7. **Table07_PGLS_Rob_Spearman** is used to get the PGLS/PIC and with robust estimators

8. **Table08_PVR_Rob_Spearman.R** is used to get the PVR union and with robust estimators

   

